// Assemble index.html, engine.js et render.js en un seul fichier autonome : match.html
// Usage : node build.js
const fs = require('fs'), path = require('path');
const read = f => fs.readFileSync(path.join(__dirname, f), 'utf8');
let html = read('index.html');
for (const f of ['engine.js', 'render.js']) {
  const tag = '<script src="' + f + '"></script>';
  if (!html.includes(tag)) throw new Error('balise introuvable : ' + tag);
  html = html.replace(tag, () => '<script>\n' + read(f).replace(/<\/script/g, '<\\/script') + '</script>');
}
fs.writeFileSync(path.join(__dirname, 'match.html'), html);
console.log('match.html écrit (' + Math.round(html.length / 1024) + ' ko)');
