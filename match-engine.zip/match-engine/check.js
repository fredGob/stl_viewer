// Vérifie que le moteur reste sain sur beaucoup de matchs : pas de valeur aberrante, pas de match qui se fige,
// et deux simulations de la même graine strictement identiques.
// Usage : node check.js [nombre de matchs]
const E = require('./engine.js');
const n = +process.argv[2] || 100, problems = [];
const bad = (seed, t, msg) => { if (problems.length < 20) problems.push(`graine ${seed} t=${t.toFixed(1)} : ${msg}`); };
function run(seed, watch) {
  const m = E.createMatch({ seed });
  let lastOwner = null, lastChange = 0, deadSince = 0;
  while (m.mode !== 'over') {
    E.step(m);
    if (!watch) continue;
    const b = m.ball;
    if (![b.x, b.y, b.z, b.vx, b.vy, b.vz].every(Number.isFinite)) { bad(seed, m.t, 'ballon : valeur non finie'); break; }
    if (Math.abs(b.x) > 58 || Math.abs(b.y) > 39) bad(seed, m.t, 'ballon très loin du terrain');
    for (const p of m.players) {
      if (![p.x, p.y, p.vx, p.vy, p.face, p.intent.tx, p.intent.ty].every(Number.isFinite)) { bad(seed, m.t, 'joueur n°' + p.num + ' : valeur non finie'); return m; }
      if (Math.hypot(p.vx, p.vy) > 10.5) bad(seed, m.t, 'joueur n°' + p.num + ' trop rapide');
    }
    if (b.owner !== lastOwner || m.mode === 'dead') { lastOwner = b.owner; lastChange = m.t; }
    if (m.t - lastChange > 25) { bad(seed, m.t, 'même situation depuis 25 s (' + (b.owner ? 'porteur n°' + b.owner.num + ' : ' + b.owner.intent.label : 'ballon libre') + ')'); lastChange = m.t; }
    if (m.mode === 'dead') { if (m.t - deadSince > 40) { bad(seed, m.t, 'arrêt de jeu interminable (' + m.restart.type + ')'); deadSince = m.t; } } else deadSince = m.t;
  }
  return m;
}
const sig = m => m.teams.map(T => T.score + ':' + T.stats.passes + ':' + T.stats.shots).join('|') + '|' + m.players.map(p => p.x.toFixed(6)).join(',');
for (let i = 1; i <= n; i++) run(i, true);
const same = sig(run(42, false)) === sig(run(42, false));
if (!same) problems.push('la même graine ne redonne pas le même match');
console.log(problems.length ? 'PROBLÈMES :\n' + problems.join('\n') : `OK : ${n} matchs sans anomalie, simulation reproductible`);
process.exit(problems.length ? 1 : 0);
