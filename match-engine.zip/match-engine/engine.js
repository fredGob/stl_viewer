/* Moteur de match — simulation pure, sans affichage.
   Repère : x le long du terrain (−52.5 … 52.5), y en largeur (−34 … 34), z en hauteur. Mètres et secondes.
   L'équipe 0 attaque vers +x, l'équipe 1 vers −x.
   « Relatif » = repère retourné pour que l'équipe considérée attaque toujours vers +x (x*dir, y*dir). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MatchEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
'use strict';

const P = { HL: 52.5, HW: 34, GOAL_HW: 3.66, GOAL_H: 2.44, BOX_D: 16.5, BOX_HW: 20.16, SIX_D: 5.5, SIX_HW: 9.16, SPOT: 11, CIRCLE_R: 9.15 };
const DT = 0.05, G = 9.81;
const ROLL_A = 0.9, ROLL_B = 0.16, AIR_K = 0.012;      // frottement au sol (a + b·v), traînée en l'air
const WALK = 1.7, JOG = 3.3, RUN = 5.3;

// ---------- utilitaires ----------
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const hyp = (x, y) => Math.sqrt(x * x + y * y);
const sigmoid = x => 1 / (1 + Math.exp(-x));
function angDiff(a, b) { let d = a - b; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; }
function interp(tab, x) {
  if (x <= tab[0][0]) return tab[0][1];
  for (let i = 1; i < tab.length; i++) if (x <= tab[i][0]) { const a = tab[i - 1], b = tab[i]; return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]); }
  return tab[tab.length - 1][1];
}
function makeRng(seed) {
  let a = seed >>> 0;
  return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

// ---------- physique du ballon ----------
function ballStep(b, dt) {
  if (b.z > 0.02 || Math.abs(b.vz) > 0.5) {
    const k = AIR_K * Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz);
    b.vx -= k * b.vx * dt; b.vy -= k * b.vy * dt; b.vz -= (G + k * b.vz) * dt;
    b.x += b.vx * dt; b.y += b.vy * dt; b.z += b.vz * dt;
    if (b.z <= 0) { b.z = 0; if (b.vz < -1.2) { b.vz = -b.vz * 0.55; b.vx *= 0.72; b.vy *= 0.72; } else b.vz = 0; }
  } else {
    b.z = 0; b.vz = 0;
    const sp = hyp(b.vx, b.vy);
    if (sp > 0) { const f = Math.max(0, sp - (ROLL_A + ROLL_B * sp) * dt) / sp; b.vx *= f; b.vy *= f; }
    b.x += b.vx * dt; b.y += b.vy * dt;
  }
}
// ballon qui roule : distance et temps pour passer de la vitesse v0 à v1
function rollDist(v0, v1) { return (v0 - v1) / ROLL_B - (ROLL_A / (ROLL_B * ROLL_B)) * Math.log((ROLL_A + ROLL_B * v0) / (ROLL_A + ROLL_B * v1)); }
function rollTime(v0, v1) { return Math.log((ROLL_A + ROLL_B * v0) / (ROLL_A + ROLL_B * v1)) / ROLL_B; }
function groundSpeedFor(d, vArr) { let lo = vArr, hi = 40; for (let i = 0; i < 22; i++) { const mid = (lo + hi) / 2; if (rollDist(mid, vArr) < d) lo = mid; else hi = mid; } return hi; }
function groundTime(v0, s) {
  if (s <= 0) return 0;
  if (rollDist(v0, 0) <= s) return Infinity;
  let lo = 0, hi = v0;
  for (let i = 0; i < 18; i++) { const mid = (lo + hi) / 2; if (rollDist(v0, mid) > s) lo = mid; else hi = mid; }
  return rollTime(v0, (lo + hi) / 2);
}
// ballon en l'air : table vitesse → (distance, temps) du premier rebond, par angle de frappe
const LOFT = {};
for (const e of [28, 38]) {
  const rows = [], er = e * Math.PI / 180;
  for (let v = 8; v <= 34; v++) {
    const b = { x: 0, y: 0, z: 0, vx: v * Math.cos(er), vy: 0, vz: v * Math.sin(er) }; let t = 0;
    do { ballStep(b, 0.02); t += 0.02; } while (b.z > 0 && t < 8);
    rows.push({ v, d: b.x, t });
  }
  LOFT[e] = rows;
}
function loftSolve(d, e) {
  const rows = LOFT[e];
  if (d <= rows[0].d) return { v: rows[0].v, t: rows[0].t };
  for (let i = 1; i < rows.length; i++) if (d <= rows[i].d) { const a = rows[i - 1], b = rows[i], u = (d - a.d) / (b.d - a.d); return { v: lerp(a.v, b.v, u), t: lerp(a.t, b.t, u) }; }
  const l = rows[rows.length - 1]; return { v: l.v, t: l.t };
}

// ---------- effectif ----------
// yD/yA : largeur en défense / en attaque ; dD/dA : distance à la ligne défensive en défense / en attaque
const SLOTS = [
  { slot: 'GK',  role: 'GK',  num: 1,  side: 0,  yD: 0,    yA: 0,   dD: 0,    dA: 0 },
  { slot: 'LB',  role: 'DEF', num: 3,  side: -1, yD: -17,  yA: -26, dD: 1.5,  dA: 11 },
  { slot: 'LCB', role: 'DEF', num: 4,  side: 0,  yD: -6,   yA: -10, dD: 0,    dA: 0 },
  { slot: 'RCB', role: 'DEF', num: 5,  side: 0,  yD: 6,    yA: 10,  dD: 0,    dA: 0 },
  { slot: 'RB',  role: 'DEF', num: 2,  side: 1,  yD: 17,   yA: 26,  dD: 1.5,  dA: 11 },
  { slot: 'LM',  role: 'MID', num: 11, side: -1, yD: -21,  yA: -28, dD: 11.5, dA: 30 },
  { slot: 'LCM', role: 'MID', num: 6,  side: 0,  yD: -4.5, yA: -6,  dD: 9,    dA: 16 },
  { slot: 'RCM', role: 'MID', num: 8,  side: 0,  yD: 6,    yA: 9,   dD: 12,   dA: 24 },
  { slot: 'RM',  role: 'MID', num: 7,  side: 1,  yD: 21,   yA: 28,  dD: 11.5, dA: 30 },
  { slot: 'LF',  role: 'FWD', num: 10, side: 0,  yD: -8,   yA: -9,  dD: 22,   dA: 40 },
  { slot: 'RF',  role: 'FWD', num: 9,  side: 0,  yD: 8,    yA: 9,   dD: 21,   dA: 36 },
];
const POSTE = { GK: 'Gardien', LB: 'Arrière gauche', LCB: 'Défenseur central', RCB: 'Défenseur central', RB: 'Arrière droit', LM: 'Milieu gauche', LCM: 'Milieu axial', RCM: 'Milieu axial', RM: 'Milieu droit', LF: 'Attaquant', RF: 'Attaquant' };
// hauteur de la ligne défensive (x relatif) selon la position du ballon (x relatif)
const DEF_LINE = [[-52.5, -47.5], [-40, -44], [-25, -37], [-10, -29], [5, -21], [25, -12], [52.5, -6]];
const ATT_LINE = [[-52.5, -41], [-35, -38], [-10, -25], [15, -11], [35, -2], [52.5, 0]];
const NAMES = ['Morel', 'Garnier', 'Faure', 'Roussel', 'Blanchard', 'Guérin', 'Boyer', 'Chevalier', 'Perrin', 'Robin', 'Masson', 'Marchand', 'Dupuis', 'Lemoine', 'Benoît', 'Renard', 'Colin', 'Vidal', 'Picard', 'Leclerc', 'Gaillard', 'Barbier', 'Arnaud', 'Brun', 'Giraud', 'Meunier', 'Aubert', 'Carpentier', 'Lacroix', 'Fabre', 'Rey', 'Hubert', 'Royer', 'Berger', 'Leroux', 'Noël', 'Poirier', 'Huet', 'Charpentier', 'Ménard', 'Bailly', 'Collet', 'Maréchal', 'Besson'];

function makePlayer(m, T, i, name) {
  const s = SLOTS[i], g = m.gauss;
  const base = () => clamp(0.6 + 0.13 * g(), 0.25, 0.97);
  const a = { pace: base(), accel: base(), stamina: base(), passing: base(), vision: base(), firstTouch: base(), dribbling: base(), finishing: base(), tackling: base(), positioning: base(), anticipation: base(), decisions: base(), composure: base(), workRate: base(), aggression: base(), flair: base(), heading: base(), offBall: base(), reflexes: 0.3, handling: 0.3 };
  const add = (k, v) => { a[k] = clamp(a[k] + v, 0.2, 0.98); };
  if (s.role === 'GK') { a.reflexes = clamp(0.68 + 0.1 * g(), 0.4, 0.97); a.handling = clamp(0.66 + 0.1 * g(), 0.4, 0.97); add('pace', -0.15); add('dribbling', -0.2); add('finishing', -0.3); }
  if (s.role === 'DEF') { add('tackling', 0.12); add('positioning', 0.1); add('heading', 0.1); add('finishing', -0.2); add('dribbling', -0.08); }
  if (s.role === 'MID') { add('passing', 0.1); add('vision', 0.1); add('stamina', 0.08); add('workRate', 0.05); }
  if (s.role === 'FWD') { add('finishing', 0.16); add('pace', 0.07); add('offBall', 0.13); add('tackling', -0.2); }
  if (s.side !== 0) { add('pace', 0.08); add('dribbling', 0.05); }
  return {
    id: T.id * 11 + i, team: T.id, idx: i, num: s.num, name, slot: s.slot, role: s.role, side: s.side, poste: POSTE[s.slot], a,
    top: 7.1 + 1.7 * a.pace, acc: 3.3 + 2.2 * a.accel,
    x: 0, y: 0, px: 0, py: 0, vx: 0, vy: 0, face: T.dir > 0 ? 0 : Math.PI, stam: 1, dist: 0,
    ax: 0, ay: 0, driftX: 0, driftY: 0,
    nextThink: m.rng() * 0.3, intent: { type: 'position', label: 'Se replace', tx: 0, ty: 0, urg: 0.3, since: 0 },
    plan: null, stunUntil: 0, noControlUntil: 0, tackleReadyAt: 0, controlReadyAt: 0, gotBallAt: -9, protectedUntil: 0, holdUntil: 0,
    setPiece: null, hands: false, firstTime: false, nextRunAt: 0, saveAt: 0,
  };
}

function createMatch(opts) {
  opts = opts || {};
  const seed = opts.seed == null ? 1 : opts.seed;
  const m = { seed, rng: makeRng(seed), t: 0, tick: 0, duration: opts.duration || 600, mode: 'dead', players: [], teams: [], events: [], pass: null, shot: null, restart: null, corner: null, path: [], icpt: [], icptTick: -9, poss: -1, playT: 0, count: {} };
  m.gauss = () => { let u = 0; while (u < 1e-9) u = m.rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * m.rng()); };
  const names = NAMES.slice();
  for (let i = names.length - 1; i > 0; i--) { const j = Math.floor(m.rng() * (i + 1)); const t = names[i]; names[i] = names[j]; names[j] = t; }
  for (let t = 0; t < 2; t++) {
    const T = { id: t, name: t === 0 ? 'Bleus' : 'Rouges', color: t === 0 ? '#2f6fdf' : '#d8423a', dir: t === 0 ? 1 : -1, score: 0, phase: 0.5, refX: 0, refY: 0, line: -30, offLine: 0, players: [],
      stats: { possT: 0, passes: 0, passesOk: 0, shots: 0, onTarget: 0, goals: 0, xg: 0, tackles: 0, interceptions: 0, blocks: 0, fouls: 0, corners: 0, offsides: 0, saves: 0 } };
    for (let i = 0; i < 11; i++) { const p = makePlayer(m, T, i, names[t * 11 + i]); T.players.push(p); m.players.push(p); }
    m.teams.push(T);
  }
  m.ball = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, px: 0, py: 0, pz: 0, owner: null, lastTouch: null };
  setRestart(m, 'kickoff', 0, 0, 0, 2);
  m.restart.ballAt = 0;
  updateContext(m);
  for (const p of m.players) { p.x = p.px = p.ax; p.y = p.py = p.ay; }
  const k = m.restart.taker; k.x = k.px = -0.5 * m.teams[0].dir; k.y = k.py = 0;
  log(m, 'kickoff', 0, 'Coup d\'envoi');
  return m;
}

function log(m, kind, team, text) { m.events.push({ t: m.t, kind, team, text }); }
function cnt(m, k, v) { m.count[k] = (m.count[k] || 0) + (v == null ? 1 : v); }
function passEnd(m, how) { const q = m.pass; if (q && q.kind === 'pass' && !q.ended) { q.ended = true; cnt(m, how + '.' + q.type); } }
function topSpeed(p) { return p.top * (0.82 + 0.18 * p.stam); }
function inOwnBox(T, x, y) { return x * T.dir < -P.HL + P.BOX_D && Math.abs(y) < P.BOX_HW; }

// temps (s) pour que le joueur q couvre la distance dd vers (tx, ty), en tenant compte de son élan
function timeToCover(m, q, dd, tx, ty) {
  const vmax = topSpeed(q);
  let t = q.stunUntil > m.t ? q.stunUntil - m.t : 0;
  if (dd <= 0) return t;
  const D = hyp(tx - q.x, ty - q.y) || 1;
  const vt = (q.vx * (tx - q.x) + q.vy * (ty - q.y)) / D;       // vitesse actuelle vers la cible
  const v0 = Math.max(0, vt);
  const tAcc = (vmax - v0) / q.acc, dAcc = (v0 + vmax) / 2 * tAcc + 0.01;
  t += dd / vmax + 0.5 * tAcc * (1 - v0 / vmax) * Math.min(1, dd / dAcc);
  if (vt < 0) t += -vt / 7.5;
  return t;
}

// ---------- valeur d'une position (probabilité approximative de marquer sur cette possession) ----------
function valueAt(T, x, y) {
  const rx = x * T.dir, dx = P.HL - rx, d = hyp(dx, y), u = (rx + P.HL) / (2 * P.HL);
  return 0.005 + 0.035 * Math.pow(u, 2.2) + 0.6 * Math.exp(-d / 7) * (0.35 + 0.65 * Math.max(0, dx / (d + 1e-6)));
}
const TURNOVER = 0.008;
function baseXg(T, x, y) {
  const dx = Math.max(0.3, P.HL - x * T.dir), ry = y * T.dir, d = hyp(dx, ry);
  const th = Math.abs(Math.atan((ry + P.GOAL_HW) / dx) - Math.atan((ry - P.GOAL_HW) / dx));   // angle sous lequel on voit le but
  return sigmoid(-1.6 + 2.8 * th - 0.105 * d);
}

// ---------- contexte d'équipe : phase de jeu, ligne défensive, positions de référence ----------
function updateContext(m) {
  const b = m.ball, R = m.restart;
  let poss = -1;
  if (m.mode === 'dead') poss = R.team;
  else if (b.owner) poss = b.owner.team;
  else if (m.pass && m.pass.kind === 'pass' && m.pass.to) poss = m.pass.from.team;
  m.poss = poss;
  let rx = b.x, ry = b.y;
  if (m.mode === 'dead') { rx = R.x; ry = R.y; }
  else if (!b.owner && m.pass && m.pass.to && m.icpt[m.pass.to.id]) { const ic = m.icpt[m.pass.to.id]; rx = (rx + ic.x) / 2; ry = (ry + ic.y) / 2; }
  for (const T of m.teams) {
    const target = poss < 0 ? 0.5 : poss === T.id ? 1 : 0;
    T.phase += clamp(target - T.phase, -0.8 * DT, 0.8 * DT);
    const k = DT / 0.45;
    T.refX += (rx * T.dir - T.refX) * k; T.refY += (ry * T.dir - T.refY) * k;
    // ligne de hors-jeu : avant-dernier adversaire, ballon ou ligne médiane
    const O = m.teams[1 - T.id]; let m1 = -99, m2 = -99;
    for (const o of O.players) { const x = o.x * T.dir; if (x > m1) { m2 = m1; m1 = x; } else if (x > m2) m2 = x; }
    T.offLine = Math.max(m2, b.x * T.dir, 0);
  }
  for (const T of m.teams) computeAnchors(m, T);
}

function computeAnchors(m, T) {
  const f = T.phase, bx = T.refX, by = T.refY, d = T.dir, b = m.ball, R = m.restart;
  let line = lerp(Math.min(interp(DEF_LINE, bx), bx - 1.5), interp(ATT_LINE, bx), f);
  line = Math.max(line, -50.5);
  T.line = line;
  const squeeze = line < -40 ? lerp(0.6, 1, (line + 50.5) / 10.5) : 1;       // bloc très bas : lignes resserrées
  const ballSide = by > 6 ? 1 : by < -6 ? -1 : 0;
  const corner = m.corner && (m.mode === 'dead' || m.t < m.corner.until) ? m.corner : null;
  for (const p of T.players) {
    const s = SLOTS[p.idx];
    let ax, ay;
    if (p.role === 'GK') {
      const gbx = b.x * d + P.HL, gby = b.y * d, dg = hyp(gbx, gby) || 1;
      const out = dg > 45 ? lerp(5.5, 12, clamp((dg - 45) / 40, 0, 1)) * (0.5 + 0.5 * f) : clamp(dg * 0.3, 1, lerp(4.5, 3, clamp((dg - 16) / 10, 0, 1)));
      ax = Math.max(-P.HL + 0.4, -P.HL + gbx / dg * out); ay = gby / dg * out;
    } else {
      ax = line + lerp(s.dD, s.dA, f) * squeeze;
      ay = lerp(s.yD, s.yA, f) + by * lerp(s.role === 'DEF' ? 0.42 : s.role === 'MID' ? 0.5 : 0.55, 0.3, f);
      if (s.role === 'DEF' && s.side !== 0) {
        if (f > 0.5 && s.side === ballSide && bx > -10) ax += 12 * (f - 0.5);     // le latéral côté ballon monte
        if (s.side === -ballSide) ay -= s.side * 4;                              // l'autre resserre
      }
      if (s.role === 'MID' && s.side !== 0 && s.side === -ballSide) { ay -= s.side * 5; if (f > 0.5 && bx > 20) { ay -= s.side * 6; ax += 4; } }
      if (s.role === 'FWD') {
        if (f >= 0.5 && bx > 28 && Math.abs(by) > 12) { ax = Math.max(ax, P.HL - 11.5); ay = (s.slot === 'LF' ? -1 : 1) === ballSide ? ballSide * 3.5 : -ballSide * 4; }   // centre possible : dans la surface
      }
      if (f > 0.3) ax = Math.min(ax, T.offLine - (s.role === 'FWD' ? 3 : 1));      // rester en jeu, avec un peu d'élan devant soi
    }
    if (corner) { const c = cornerSpot(p, T, corner); if (c) { ax = c[0]; ay = c[1]; } }
    ax = clamp(ax, -P.HL + 0.4, P.HL - 3); ay = clamp(ay, -30.5, 30.5);
    if (R && R.type === 'kickoff') {
      ax = Math.min(ax, -1.2);
      if (T.id !== R.team && hyp(ax, ay) < P.CIRCLE_R + 0.6) { const n = hyp(ax, ay) || 1; ax = Math.min(-1.2, ax / n * (P.CIRCLE_R + 0.6)); ay = (ay / n || 1) * Math.sqrt(Math.max(0, (P.CIRCLE_R + 0.6) ** 2 - ax * ax)); }
      if (T.id === R.team && s.slot === 'RF') { ax = -0.8; ay = 2.5; }
    }
    if (R && R.type === 'penalty' && p.role !== 'GK') {
      const att = T.id === R.team;
      if (att) ax = Math.min(ax, P.HL - P.BOX_D - 1.5); else ax = Math.max(ax, -P.HL + P.BOX_D + 1.5);
    }
    if (R && R.type === 'penalty' && p.role === 'GK' && T.id !== R.team) { ax = -P.HL + 0.3; ay = 0; }
    p.ax = ax * d; p.ay = ay * d;
  }
}

// positions sur corner (repère relatif), n = +1 du côté du corner
function cornerSpot(p, T, c) {
  const att = T.id === c.team, n = c.side * T.dir || 1, s = p.slot;
  if (att) {
    if (s === 'LF') return [47, n * 2.5]; if (s === 'RF') return [43, -n]; if (s === 'LCB') return [45.5, -n * 4.5]; if (s === 'RCB') return [41, n * 5.5];
    if (s === 'LCM') return [34, n * 4]; if (s === 'RCM') return [3, 0]; if (s === 'LB') return [-10, -13]; if (s === 'RB') return [-10, 13];
    if (p.role === 'MID' && p.side === -n) return [38.5, -n * 9];
    return null;
  }
  if (s === 'GK') return [-52, -n * 0.6];
  if (s === 'LB') return [-48.5, -5]; if (s === 'LCB') return [-48, -1.5]; if (s === 'RCB') return [-48, 2]; if (s === 'RB') return [-48.5, 5.5];
  if (s === 'LCM') return [-44.5, -3]; if (s === 'RCM') return [-44.5, 3.5]; if (s === 'LF') return [-37, n * 2]; if (s === 'RF') return [-18, 0];
  return p.side === n ? [-47, n * 10] : [-42, -n * 8];
}

// ---------- trajectoire prévue du ballon et temps d'interception de chaque joueur ----------
function predict(m) {
  const b = m.ball, s = { x: b.x, y: b.y, z: b.z, vx: b.vx, vy: b.vy, vz: b.vz }, path = m.path;
  path.length = 0; path.push({ x: s.x, y: s.y, z: s.z, t: 0 });
  for (let i = 1; i <= 110; i++) {
    ballStep(s, DT);
    path.push({ x: s.x, y: s.y, z: s.z, t: i * DT });
    if (Math.abs(s.x) > P.HL + 0.5 || Math.abs(s.y) > P.HW + 0.5) break;
    if (s.z === 0 && s.vx * s.vx + s.vy * s.vy < 0.05) break;
  }
  for (const p of m.players) m.icpt[p.id] = intercept(m, p);
  m.icptTick = m.tick;
}
function intercept(m, p) {
  const path = m.path, keeper = p.role === 'GK' && inOwnBox(m.teams[p.team], p.x, p.y);
  const reach = keeper ? 1.1 : 0.7, zMax = keeper ? 2.6 : 2.3;
  for (let i = 0; i < path.length; i++) {
    const q = path[i]; if (q.z > zMax) continue;
    const dd = hyp(q.x - p.x, q.y - p.y) - reach;
    if (dd <= 0 || timeToCover(m, p, dd, q.x, q.y) <= q.t) return { t: q.t, x: q.x, y: q.y, z: q.z };
  }
  const q = path[path.length - 1], dd = Math.max(0, hyp(q.x - p.x, q.y - p.y) - reach);
  return { t: Math.max(q.t, timeToCover(m, p, dd, q.x, q.y)), x: q.x, y: q.y, z: q.z };
}

// ---------- le cerveau de chaque joueur ----------
function setIntent(m, p, type, label, tx, ty, urg) {
  const it = p.intent;
  if (it.type !== type) it.since = m.t;
  it.type = type; it.label = label; it.tx = tx; it.ty = ty; it.urg = urg;
}
// les joueurs ne réagissent pas tous au même instant : chacun a son temps de réaction
function react(m, quick) {
  for (const p of m.players) { const r = (0.10 + 0.28 * (1 - p.a.anticipation)) * (0.6 + 0.8 * m.rng()) * (p === quick ? 0.4 : 1); if (p.nextThink > m.t + r) p.nextThink = m.t + r; }
}
function threat(m) {
  const b = m.ball;
  if (b.owner) return { x: b.owner.x, y: b.owner.y, player: b.owner };
  if (m.pass && m.pass.to && m.icpt[m.pass.to.id]) { const ic = m.icpt[m.pass.to.id]; return { x: ic.x, y: ic.y, player: m.pass.to }; }
  return { x: b.x, y: b.y, player: null };
}
function pressure(m, p) {
  let dmin = 99;
  for (const o of m.teams[1 - p.team].players) { if (o.stunUntil > m.t) continue; const dd = hyp(o.x - p.x, o.y - p.y); if (dd < dmin) dmin = dd; }
  return clamp(1 - (dmin - 1.3) / 4.5, 0, 1);
}
function oppDist(O, x, y) { let dmin = 99; for (const o of O.players) { const dd = hyp(o.x - x, o.y - y); if (dd < dmin) dmin = dd; } return dmin; }

function think(m, p) {
  const base = p.role === 'GK' ? 0.16 : 0.36 - 0.14 * p.a.decisions;
  p.nextThink = m.t + base * (0.75 + 0.5 * m.rng());
  const sd = 1.6 * (1.3 - p.a.positioning);                 // petit écart personnel à la position théorique
  p.driftX = p.driftX * 0.9 + m.gauss() * sd * 0.44; p.driftY = p.driftY * 0.9 + m.gauss() * sd * 0.44;
  if (p.stunUntil > m.t) return;
  if (m.mode === 'dead') return thinkRestart(m, p);
  const b = m.ball;
  if (b.owner === p) return thinkCarrier(m, p);
  if (p.role === 'GK') return thinkKeeper(m, p);
  if (!b.owner) {
    if (m.pass && m.pass.to === p) return setIntent(m, p, 'receive', 'Va chercher la passe', b.x, b.y, 0.9);
    if (wantsChase(m, p)) return setIntent(m, p, 'chase', 'Va au ballon', b.x, b.y, 1);
  }
  const attacking = m.poss < 0 ? m.teams[p.team].phase > 0.5 : m.poss === p.team;
  if (attacking) thinkSupport(m, p); else thinkDefend(m, p, false);
}

function wantsChase(m, p) {
  const me = m.icpt[p.id]; if (!me) return false;
  const pass = m.pass, T = m.teams[p.team], chasing = p.intent.type === 'chase';
  const noise = () => 0.12 * (1.3 - p.a.anticipation) * m.gauss();
  if (pass && pass.to && pass.kind === 'pass') {
    const rec = m.icpt[pass.to.id];
    if (pass.to.team === p.team) return me.t < rec.t - 0.8;                       // un coéquipier est servi
    if (me.t > rec.t - 0.05 + noise() + (chasing ? 0.25 : 0)) return false;       // je n'arriverai pas avant lui
  }
  let better = 0;
  for (const q of T.players) {
    if (q === p || (q.role === 'GK' && !inOwnBox(T, me.x, me.y))) continue;
    if (m.icpt[q.id].t + noise() < me.t - (chasing ? 0.45 : 0.12)) better++;
  }
  return better === 0 || (better === 1 && me.x * T.dir < -25);
}

function pressCost(m, q, th, gx) {
  let ux = gx - th.x, uy = -th.y; const n = hyp(ux, uy) || 1; ux /= n; uy /= n;
  const tx = th.x + ux * 1.5, ty = th.y + uy * 1.5;
  let c = timeToCover(m, q, hyp(tx - q.x, ty - q.y), tx, ty);
  if (q.role === 'DEF' && q.side === 0 && n > 30) c += 1.0;      // un central ne sort pas au milieu de terrain
  if (q.role === 'GK') c += 99;
  if (q.intent.type === 'press') c -= 0.4;
  return c;
}

function thinkDefend(m, p, noPress) {
  const T = m.teams[p.team], O = m.teams[1 - p.team], d = T.dir, b = m.ball;
  const gx = -P.HL * d, th = threat(m), c = th.player;
  const dGoalTh = hyp(th.x - gx, th.y);
  const ax = p.ax + p.driftX, ay = p.ay + p.driftY;
  if (!noPress && c && c.team !== p.team && !(c.protectedUntil > m.t)) {
    const mine = pressCost(m, p, th, gx);
    let rank = 0;
    for (const q of T.players) if (q !== p && pressCost(m, q, th, gx) + 0.1 * m.gauss() < mine) rank++;
    const dAnch = hyp(th.x - p.ax, th.y - p.ay), dMe = hyp(th.x - p.x, th.y - p.y);
    const zone = (p.role === 'DEF' ? 11 : 15) + (p.intent.type === 'press' ? 5 : 0);
    if (rank === 0 && (dAnch < zone || th.x * d < -17.5 || dMe < 5)) return setIntent(m, p, 'press', 'Presse le n°' + c.num, th.x, th.y, 1);
    if (rank === 1 && th.x * d < -17.5 && dMe < 12 && T.players.some(q => q.intent.type === 'press' && m.t - q.intent.since > 2.5)) return setIntent(m, p, 'press', 'Vient aider sur le n°' + c.num, th.x, th.y, 1);
    if (rank === 1 && dGoalTh < 42 && dAnch < zone + 6) {
      const ux = gx - th.x, uy = -th.y, n = hyp(ux, uy) || 1;
      return setIntent(m, p, 'position', 'Couvre son coéquipier', lerp(ax, th.x + ux / n * 6.5, 0.6), lerp(ay, th.y + uy / n * 6.5, 0.6), 0.75);
    }
  }
  // marquage : l'adversaire le plus dangereux de ma zone
  const zoneR = p.role === 'DEF' ? 13 : 10;
  let best = null, bs = 0, bd = 0;
  for (const o of O.players) {
    if (o.role === 'GK' || o === c) continue;
    const running = o.intent.type === 'run' && p.role === 'DEF';
    const dd = hyp(o.x - p.ax, o.y - p.ay) * (running ? 0.6 : 1); if (dd > zoneR) continue;
    const s = (1 - dd / zoneR) * (1.2 - clamp(hyp(o.x - gx, o.y) / 60, 0, 1)) * (running ? 1.5 : 1);
    if (s > bs) { bs = s; best = o; bd = dd; }
  }
  let tx = ax, ty = ay, label = 'Garde sa zone';
  if (best) {
    const og = hyp(best.x - gx, best.y) || 1;
    const tight = clamp(1.1 - og / 45, 0.25, 1) * (p.role === 'DEF' ? 1 : p.role === 'MID' ? 0.7 : 0.3);
    const md = 1.2 + 2.5 * (1 - tight);
    const ob = hyp(b.x - best.x, b.y - best.y) || 1;
    const mx = best.x + (gx - best.x) / og * md + (b.x - best.x) / ob * 0.8, my = best.y + (0 - best.y) / og * md + (b.y - best.y) / ob * 0.8;
    let w = clamp((1 - bd / zoneR) * 1.4, 0, 1) * tight, lx = 0, ly = 0;
    if (best.intent.type === 'run' && p.role === 'DEF') { w = Math.max(w, 0.9); lx = best.vx * 0.5; ly = best.vy * 0.5; }      // il anticipe la course
    tx = lerp(ax, mx + lx, w); ty = lerp(ay, my + ly, w);
    if (w > 0.3) label = (lx || ly ? 'Suit l\'appel du n°' : 'Marque le n°') + best.num;
  }
  let urg = 0.35;
  if (hyp(th.x - p.x, th.y - p.y) < 25) urg = 0.6;
  if (dGoalTh < 35 && p.role !== 'FWD') urg = 0.75;
  if ((tx - p.x) * d < -6 || (best && best.intent.type === 'run' && p.role === 'DEF')) { urg = Math.max(urg, 0.95); if (!best) label = 'Se replie'; }
  setIntent(m, p, 'position', label, tx, ty, urg);
}

// marge minimale (m) laissée par les adversaires autour d'une ligne de passe
function laneOpen(O, bx, by, qx, qy) {
  const dx = qx - bx, dy = qy - by, D = hyp(dx, dy) || 1, ux = dx / D, uy = dy / D; let mn = 9;
  for (const o of O.players) { const rx = o.x - bx, ry = o.y - by, s = rx * ux + ry * uy; if (s < 1 || s > D + 1) continue; const v = Math.abs(rx * uy - ry * ux) - 0.22 * s; if (v < mn) mn = v; }
  return mn;
}

function thinkSupport(m, p) {
  const T = m.teams[p.team], O = m.teams[1 - p.team], d = T.dir, b = m.ball, it = p.intent;
  const th = threat(m), carrier = b.owner && b.owner.team === p.team ? b.owner : null;
  const ax = p.ax + p.driftX, ay = p.ay + p.driftY;
  if (it.type === 'run' && m.t < it.until) return;
  const dB = hyp(ax - th.x, ay - th.y);
  // appel en profondeur
  if ((p.role === 'FWD' || (p.role === 'MID' && p.side !== 0)) && carrier && !carrier.setPiece && dB < 38 && th.x * d > -15 && m.t > p.nextRunAt
      && T.offLine < P.HL - 14 && pressure(m, carrier) < 0.7 && m.rng() < 0.08 + 0.22 * p.a.offBall) {
    const tx = Math.min(T.offLine + 14, 46) * d, ty = clamp(p.y * 0.55 + 4 * m.gauss(), -26, 26);
    setIntent(m, p, 'run', 'Appel en profondeur', tx, ty, 1);
    it.until = m.t + 2.2; p.nextRunAt = m.t + 6 + 6 * m.rng();
    return;
  }
  let bx = ax, by = ay, bsc = -1e9;
  if (dB < 34) {
    const rings = dB < 20 ? [0, 5, 9] : [0, 5];
    for (const r of rings) for (let k = 0; k < (r ? 8 : 1); k++) {
      const qx = ax + r * Math.cos(k * Math.PI / 4), qy = ay + r * Math.sin(k * Math.PI / 4);
      if (Math.abs(qx) > 51.5 || Math.abs(qy) > 33) continue;
      const rx = qx * d; if (rx > T.offLine - 0.6) continue;
      const dq = hyp(qx - th.x, qy - th.y);
      let s = 0.8 * clamp(oppDist(O, qx, qy) / 9, 0, 1);                         // de l'espace
      s += clamp(laneOpen(O, th.x, th.y, qx, qy) / 3, -1, 1);                    // une ligne de passe ouverte
      if (dq < 7) s -= (7 - dq) * 0.25;                                          // pas dans les pieds du porteur
      s -= 0.012 * r * r;                                                        // sans trop quitter son poste
      s += 0.03 * (rx - ax * d) * (p.role === 'FWD' ? 1.3 : 1);                   // de préférence vers l'avant
      for (const q of T.players) { if (q === p || q === carrier) continue; const dm = hyp(qx - q.x, qy - q.y); if (dm < 8) s -= (8 - dm) * 0.08; }
      if (hyp(qx - it.tx, qy - it.ty) < 2.5) s += 0.15;                          // ne change pas d'avis sans raison
      if (s > bsc) { bsc = s; bx = qx; by = qy; }
    }
  }
  const moved = hyp(bx - ax, by - ay) > 2;
  setIntent(m, p, 'position', moved ? 'Se démarque' : dB < 34 ? 'Propose une solution' : 'Garde sa position', bx, by, dB < 20 ? 0.6 : dB < 34 ? 0.45 : 0.3);
}

// le ballon file-t-il vers le cadre ? renvoie le point où il passe à la hauteur du gardien
function goalThreat(m, p) {
  const b = m.ball, d = m.teams[p.team].dir, path = m.path;
  if (b.vx * d > -6) return null;
  let at = null, last = null;
  for (let i = 0; i < path.length; i++) {
    const q = path[i];
    if (q.x * d <= -P.HL) return (Math.abs(q.y) < P.GOAL_HW + 1 && q.z < P.GOAL_H + 0.8) ? (at || last) : null;
    if (q.x * d <= p.x * d + 0.2) { last = q; if (!at && q.z <= 2.4) at = q; }
  }
  return null;
}

function thinkKeeper(m, p) {
  const b = m.ball, T = m.teams[p.team], O = m.teams[1 - p.team];
  if (!b.owner) {
    if (m.pass && m.pass.to === p) return setIntent(m, p, 'receive', 'Va chercher la passe', b.x, b.y, 0.9);
    const c = goalThreat(m, p);
    if (c) { if (p.intent.type !== 'save') p.saveAt = m.t + 0.04 + 0.08 * (1 - p.a.reflexes); return setIntent(m, p, 'save', 'Plonge', c.x, c.y, 1); }
    const me = m.icpt[p.id];
    if (me) {
      let tOpp = 99, tMate = 99;
      for (const o of O.players) tOpp = Math.min(tOpp, m.icpt[o.id].t);
      for (const q of T.players) if (q !== p) tMate = Math.min(tMate, m.icpt[q.id].t);
      const h = p.intent.type === 'claim' ? 0.3 : 0, box = inOwnBox(T, me.x, me.y);
      if ((box && me.t < tOpp - 0.15 + h && me.t < tMate + 0.4 + h) || (!box && hyp(me.x + P.HL * T.dir, me.y) < 30 && me.t < tOpp - 0.7 + h && me.t < tMate - 0.2 + h))
        return setIntent(m, p, 'claim', 'Sort sur le ballon', me.x, me.y, 1);
    }
  }
  const c = b.owner;
  if (c && c.team !== p.team && inOwnBox(T, c.x, c.y) && hyp(c.x - p.x, c.y - p.y) < (p.intent.type === 'claim' ? 11 : 8)) {
    const gx = -P.HL * T.dir, dc = hyp(c.x - gx, c.y); let covered = false;
    for (const q of T.players) if (q !== p && hyp(q.x - c.x, q.y - c.y) < 2.5 && hyp(q.x - gx, q.y) < dc) covered = true;      // un défenseur est déjà entre lui et le but
    if (!covered) return setIntent(m, p, 'claim', 'Sort dans les pieds', c.x, c.y, 1);
  }
  setIntent(m, p, 'position', 'Se place', p.ax, p.ay, 0.7);
}

function thinkRestart(m, p) {
  const R = m.restart, T = m.teams[p.team];
  if (p === R.taker) {
    const n = hyp(R.x, R.y) || 1, ux = R.x / n, uy = R.y / n;        // se place derrière le ballon, dos à la touche
    const off = R.type === 'kickoff' ? 0 : 0.5;
    const tx = R.type === 'kickoff' ? -0.5 * T.dir : R.x + ux * off, ty = R.type === 'kickoff' ? 0 : R.y + uy * off;
    return setIntent(m, p, 'toBall', 'Va jouer le ballon', tx, ty, 0.7);
  }
  const free = R.type === 'throwin' || R.type === 'freekick' || R.type === 'goalkick';
  if (p.role === 'GK' || !free) setIntent(m, p, 'position', 'Se replace', p.ax, p.ay, 0.4);
  else if (p.team === R.team) thinkSupport(m, p); else thinkDefend(m, p, true);
  // distance réglementaire
  const it = p.intent, need = p.team === R.team ? (R.type === 'kickoff' ? 0 : 3) : R.type === 'throwin' ? 2.5 : 9.6;
  const dd = hyp(it.tx - R.x, it.ty - R.y);
  if (dd < need) { const ux = dd > 0.1 ? (it.tx - R.x) / dd : -T.dir, uy = dd > 0.1 ? (it.ty - R.y) / dd : 0; it.tx = R.x + ux * need; it.ty = R.y + uy * need; }
  if (it.urg > 0.5) it.urg = 0.5;
}

// ---------- le porteur du ballon : il note ses options et choisit ----------
function passAcc(p, D, pr, off, lofted) {
  const e = (0.02 + 0.0035 * D) * (1.7 - 1.1 * p.a.passing) * (1 + 1.3 * pr) * (1 + 0.35 * off) * (lofted ? 1.7 : 1);
  return clamp(1 - e, 0.3, 0.995);
}
// probabilité qu'une passe au sol ne soit pas coupée en route
function laneProb(m, p, qx, qy, D, v0, O) {
  const ux = (qx - p.x) / D, uy = (qy - p.y) / D; let ok = 1;
  for (const o of O.players) {
    const rx = o.x - p.x, ry = o.y - p.y; let s = rx * ux + ry * uy;
    if (s < 0.5 || s > D + 0.5) continue;
    s = Math.min(s, D);
    const perp = Math.abs(rx * uy - ry * ux), keeper = o.role === 'GK' && inOwnBox(m.teams[o.team], o.x, o.y);
    const to = 0.25 + timeToCover(m, o, Math.max(0, perp - (keeper ? 1.2 : 0.9)), p.x + ux * s, p.y + uy * s);
    ok *= 1 - 0.95 * sigmoid(-(to - groundTime(v0, s)) / 0.18);
  }
  return ok;
}
function fastestOpp(m, O, qx, qy) {
  let tO = 99;
  for (const o of O.players) { const keeper = o.role === 'GK' && inOwnBox(m.teams[o.team], qx, qy); const dd = Math.max(0, hyp(o.x - qx, o.y - qy) - (keeper ? 1.2 : 0.8)); const t = timeToCover(m, o, dd, qx, qy) + 0.25; if (t < tO) tO = t; }
  return tO;
}

function passOption(m, p, q, pr, sp, hands, risk) {
  const T = m.teams[p.team], O = m.teams[1 - p.team], d = T.dir, b = m.ball, a = p.a;
  const D0 = hyp(q.x - p.x, q.y - p.y);
  if (D0 < 3.5) return null;
  const exempt = sp === 'throwin' || sp === 'goalkick' || sp === 'corner';
  if (!exempt && q.x * d > T.offLine + 0.2 && m.rng() < 0.75 + 0.25 * a.vision) return null;      // il voit que le partenaire est hors-jeu
  const off = Math.abs(angDiff(Math.atan2(q.y - p.y, q.x - p.x), p.face));
  const seen = (off < 1.6 || sp) ? 1 : 0.55 + 0.4 * a.vision;                                      // partenaire dans son dos
  const maxV = hands ? 16 : sp === 'throwin' ? 13 : 24;
  let best = null;
  const keep = o => { if (!best || o.u > best.u) best = o; };
  const score = (pOk, qx, qy, space, lossX, lossY, scale) => pOk * valueAt(T, qx, qy) * space * scale - (1 - pOk) * (valueAt(O, lossX, lossY) + TURNOVER) * risk + pOk * 0.0004 * scale * clamp((qx - p.x) * d, -15, 15);
  // (A) dans les pieds
  {
    const v0 = Math.min(maxV, groundSpeedFor(D0, 8.5 + 0.04 * D0)), tb = groundTime(v0, D0);
    if (tb < 3.2) {
      const lead = Math.min(tb, 0.7) * 0.6, qx = q.x + q.vx * lead, qy = q.y + q.vy * lead, D = hyp(qx - p.x, qy - p.y) || 1;
      const dOpp = oppDist(O, qx, qy);
      const pOk = laneProb(m, p, qx, qy, D, v0, O) * passAcc(p, D, pr, off, false) * (0.985 - 0.22 * clamp(1 - (dOpp - 0.8) / 2.5, 0, 1)) * seen;
      keep({ kind: 'pass', u: score(pOk, qx, qy, 0.72 + 0.28 * clamp(dOpp / 8, 0, 1), (p.x + qx) / 2, (p.y + qy) / 2, 1), to: q, qx, qy, v0, lofted: false, feet: true, pOk });
    }
  }
  if (q.role === 'GK') return best;
  // direction de course du partenaire : son élan, sinon le but
  let ux = P.HL * d - q.x, uy = -q.y * 0.5; let n = hyp(ux, uy) || 1; ux /= n; uy /= n;
  const sq = hyp(q.vx, q.vy);
  if (sq > 2) { ux = ux * 0.5 + q.vx / sq * 0.5; uy = uy * 0.5 + q.vy / sq * 0.5; n = hyp(ux, uy) || 1; ux /= n; uy /= n; }
  // (B) dans la course, au sol
  if (!hands && q.x * d > p.x * d - 8) for (const L of [9, 16]) {
    const qx = q.x + ux * L, qy = q.y + uy * L; if (Math.abs(qx) > 50.5 || Math.abs(qy) > 32.5) continue;
    const D = hyp(qx - p.x, qy - p.y); if (D < 8 || D > 45) continue;
    const tr = timeToCover(m, q, L, qx, qy) + 0.15;
    let v0 = maxV;
    if (groundTime(maxV, D) < tr) { let lo = 6, hi = maxV; for (let i = 0; i < 12; i++) { const mid = (lo + hi) / 2; if (groundTime(mid, D) > tr) lo = mid; else hi = mid; } v0 = hi; }
    const tb = groundTime(v0, D), tArr = Math.max(tr, tb), tO = fastestOpp(m, O, qx, qy);
    const pOk = sigmoid((tO - tArr) / 0.3) * laneProb(m, p, qx, qy, D, v0, O) * passAcc(p, D, pr, off, false) * 0.97 * seen;
    keep({ kind: 'pass', u: score(pOk, qx, qy, 0.8 + 0.2 * clamp(tO - tArr, 0, 1), (p.x + qx) / 2, (p.y + qy) / 2, 1), to: q, qx, qy, v0, lofted: false, pOk });
  }
  // (C) en l'air
  if (D0 > 20 && sp !== 'throwin') for (const L of [0, 10]) {
    const qx = q.x + ux * L, qy = q.y + uy * L; if (Math.abs(qx) > 50.5 || Math.abs(qy) > 32.5) continue;
    const D = hyp(qx - p.x, qy - p.y); if (D < 18 || D > 62) continue;
    const lo = loftSolve(D, 28), tr = L ? timeToCover(m, q, L, qx, qy) + 0.15 : 0, tO = fastestOpp(m, O, qx, qy);
    const arrR = Math.max(tr, lo.t), arrO = Math.max(tO, lo.t);
    const win = arrR === arrO ? 0.5 + 0.3 * Math.tanh((tO - tr) / 0.6) : sigmoid((arrO - arrR) / 0.3);
    const pOk = win * passAcc(p, D, pr, off, true) * 0.85 * seen;
    keep({ kind: 'pass', u: score(pOk, qx, qy, 0.6 + 0.4 * clamp(oppDist(O, qx, qy) / 8, 0, 1), qx, qy, qx * d > P.HL - P.BOX_D && Math.abs(qy) < P.BOX_HW ? 0.9 : 0.6), to: q, qx, qy, v0: lo.v, lofted: true, elev: 28, pOk });
  }
  return best;
}

function shotXg(m, p, pr) {
  const T = m.teams[p.team], O = m.teams[1 - p.team], gx = P.HL * T.dir;
  let xg = baseXg(T, p.x, p.y) * (1 - 0.6 * pr) * (0.8 + 0.4 * p.a.finishing);
  const D = hyp(gx - p.x, p.y) || 1, ux = (gx - p.x) / D, uy = -p.y / D;
  for (const o of O.players) { if (o.role === 'GK') continue; const rx = o.x - p.x, ry = o.y - p.y, s = rx * ux + ry * uy; if (s > 0.5 && s < Math.min(D, 12) && Math.abs(rx * uy - ry * ux) < 0.9) xg *= 0.65; }
  return clamp(xg, 0.003, 0.95);
}

const DRIB = [0, 0.45, -0.45, 0.95, -0.95, 1.6, -1.6, 2.6, -2.6];
function thinkCarrier(m, p) {
  const b = m.ball, T = m.teams[p.team], O = m.teams[1 - p.team], a = p.a, rng = m.rng, d = T.dir;
  if (p.plan) return;
  if (m.t < p.controlReadyAt) { setIntent(m, p, 'control', 'Contrôle le ballon', p.x, p.y, 0.2); p.nextThink = p.controlReadyAt; return; }
  p.nextThink = m.t + 0.16 + 0.14 * rng();
  const sp = p.setPiece, hands = p.hands;
  if (hands && m.t < p.holdUntil) return setIntent(m, p, 'hold', 'Garde le ballon en main', p.x, p.y, 0.1);
  const pr = sp || hands ? 0 : pressure(m, p);
  const gx = P.HL * d, dGoal = hyp(gx - p.x, p.y);
  const vHere = valueAt(T, p.x, p.y), lossHere = valueAt(O, p.x, p.y) + TURNOVER, risk = 1.15 - 0.4 * a.flair;
  const opts = [];
  if ((!sp || sp === 'freekick' || sp === 'penalty') && !hands && dGoal < 28) { const xg = shotXg(m, p, pr); opts.push({ kind: 'shot', u: sp === 'penalty' ? 9 : xg * (dGoal > 20 ? 0.6 : 1), xg }); }
  if (sp !== 'penalty') for (const q of T.players) { if (q === p) continue; const o = passOption(m, p, q, pr, sp, hands, risk); if (o) opts.push(o); }
  if (!sp && !hands) {
    const w = clamp(1 - dGoal / 45, 0, 1) * 0.9, base = Math.atan2(-p.y * w, gx - p.x), ds = Math.min(topSpeed(p) * 0.86, 6.8);
    for (const offA of DRIB) {
      const ang = base + offA, dx = Math.cos(ang), dy = Math.sin(ang), L = 5.5, qx = p.x + dx * L, qy = p.y + dy * L;
      if (Math.abs(qx) > P.HL - 1.2 || Math.abs(qy) > P.HW - 1.2) continue;
      let keepP = 1, free = 99;
      for (const o of O.players) {
        const rx = o.x - p.x, ry = o.y - p.y, dO = hyp(rx, ry); if (dO > 14) continue;
        if (dO < 5.8) keepP *= 1 - 0.5 * clamp(1 - (dO - 1.3) / 4.5, 0, 1) * (0.6 + 0.4 * (rx * dx + ry * dy) / (dO || 1));
        const s = clamp(rx * dx + ry * dy, 0, L), perp = hyp(rx - dx * s, ry - dy * s);
        if (perp < free) free = perp;
        const tO = 0.12 + timeToCover(m, o, Math.max(0, perp - 1.1), p.x + dx * s, p.y + dy * s);
        keepP *= 1 - sigmoid(-(tO - s / ds) / 0.22) * clamp(0.45 + 0.5 * (o.a.tackling - a.dribbling), 0.15, 0.8);
      }
      let u = keepP * valueAt(T, qx, qy) - (1 - keepP) * lossHere * risk + 0.0005 * (qx - p.x) * d - 0.0015 * Math.abs(angDiff(ang, p.face)) - 0.12 * vHere;
      if (p.intent.type === 'dribble' && p.intent.dx * dx + p.intent.dy * dy > 0.9) u += 0.001;
      opts.push({ kind: 'dribble', u, dx, dy, speed: free > 6 ? ds : Math.min(ds, RUN * (0.95 + 0.2 * a.pace)) });
    }
    const waited = p.intent.type === 'hold' ? m.t - p.intent.since : 0;
    opts.push({ kind: 'hold', u: vHere * (1 - 0.5 * pr - Math.min(0.9, 0.35 * waited)) - pr * 0.6 * lossHere * risk - 0.0008 });
    if (p.x * d < -18 && pr > 0.5) opts.push({ kind: 'clear', u: -0.008 });
  }
  if (hands) opts.push({ kind: 'clear', u: 0.004 });
  if (!opts.length) return setIntent(m, p, 'hold', 'Cherche une solution', p.x, p.y, 0.1);
  // choix : la meilleure option le plus souvent, mais pas toujours (lucidité, pression)
  let top = -1e9, sum = 0; for (const o of opts) if (o.u > top) top = o.u;
  const tau = (0.03 + 0.08 * (1 - a.decisions) + 0.08 * pr * (1 - a.composure)) * Math.max(Math.abs(top), 0.004);      // l'écart toléré se mesure à l'enjeu
  for (const o of opts) { o.w = Math.exp((o.u - top) / tau); sum += o.w; }
  let r = rng() * sum, pick = opts[0]; for (const o of opts) { r -= o.w; if (r <= 0) { pick = o; break; } }
  cnt(m, 'choix.' + pick.kind);

  if (pick.kind === 'dribble') { setIntent(m, p, 'dribble', 'Conduit le ballon', p.x + pick.dx * 6, p.y + pick.dy * 6, 0.8); p.intent.dx = pick.dx; p.intent.dy = pick.dy; p.intent.speed = pick.speed; return; }
  if (pick.kind === 'hold') {
    setIntent(m, p, 'hold', pr > 0.4 ? 'Protège le ballon' : 'Lève la tête', p.x, p.y, 0.1);
    p.intent.shield = null;
    if (pr > 0.4) { let dn = 99, no = null; for (const o of O.players) { const dd = hyp(o.x - p.x, o.y - p.y); if (dd < dn) { dn = dd; no = o; } } p.intent.shield = Math.atan2(p.y - no.y, p.x - no.x); }      // dos à l'adversaire
    return;
  }
  let ang, label;
  if (pick.kind === 'pass') { ang = Math.atan2(pick.qy - p.y, pick.qx - p.x); label = (pick.lofted ? (Math.abs(p.y) > 16 && p.x * d > 25 ? 'Centre vers ' : 'Long ballon vers ') : pick.feet ? 'Passe à ' : 'Passe en profondeur pour ') + pick.to.name; }
  else if (pick.kind === 'shot') { ang = Math.atan2(-p.y, gx - p.x); label = 'Tire au but'; }
  else { ang = Math.atan2((p.y >= 0 ? 1 : -1) * 0.35 * d, d) + 0.15 * m.gauss(); label = 'Dégage'; }
  const turn = Math.abs(angDiff(ang, p.face));
  pick.ang = ang; pick.at = m.t + 0.10 + 0.22 * turn / Math.PI + (pick.kind === 'shot' ? 0.12 : 0) + (sp ? 0.3 : 0);
  pick.firstTime = p.firstTime && m.t - p.gotBallAt < 0.25;
  p.plan = pick;
  setIntent(m, p, 'kick', label, p.x, p.y, 0.3);
}

function executePlan(m, p) {
  const pl = p.plan, b = m.ball, T = m.teams[p.team], a = p.a, d = T.dir, g = m.gauss, rng = m.rng;
  const sp = p.setPiece, pr = sp || p.hands ? 0 : pressure(m, p);
  p.plan = null;
  let ang, vh, vz = 0, to = null;
  if (pl.kind === 'pass') {
    to = pl.to;
    if (!sp && to.x * d > T.offLine + 0.3 && m.rng() < 0.5 + 0.5 * a.vision) { p.nextThink = m.t; return; }
    let qx = pl.qx, qy = pl.qy, v0 = pl.v0;
    if (pl.feet) { const D0 = hyp(to.x - p.x, to.y - p.y); v0 = Math.min(v0 * 1.15, groundSpeedFor(D0, 8.5 + 0.04 * D0)); const lead = Math.min(groundTime(v0, D0), 0.7) * 0.6; qx = to.x + to.vx * lead; qy = to.y + to.vy * lead; }
    const off = Math.abs(angDiff(Math.atan2(qy - p.y, qx - p.x), p.face));
    const sig = (0.016 + 0.032 * (1 - a.passing)) * (1 + 1.2 * pr) * (1 + 0.3 * off) * (pl.lofted ? 1.6 : 1) * (pl.firstTime ? 1.4 : 1);
    ang = Math.atan2(qy - p.y, qx - p.x) + sig * g();
    const v = v0 * (1 + 0.05 * g());
    if (pl.lofted) { const e = pl.elev * Math.PI / 180 + 0.03 * g(); vh = v * Math.cos(e); vz = v * Math.sin(e); } else vh = v;
    T.stats.passes++;
  } else if (pl.kind === 'shot') {
    const gx = P.HL * d, gk = m.teams[1 - p.team].players[0];
    let side = gk.y > 0 ? -1 : 1; if (rng() < 0.25) side = -side;                    // vise le côté ouvert, le plus souvent
    const aimY = side * (0.5 + (P.GOAL_HW - 1.0) * Math.pow(rng(), 0.7)), aimZ = 0.2 + 1.9 * Math.pow(rng(), 1.3);
    const D = hyp(gx - p.x, aimY - p.y), v = 21 + 8 * (0.4 + 0.6 * a.finishing), tf = D / (v * 0.93);
    ang = Math.atan2(aimY - p.y, gx - p.x) + (0.075 + 0.12 * (1 - a.finishing)) * (1 + 0.7 * pr) * (1 + D / 60) * g();
    vh = v; vz = aimZ / tf + 0.5 * G * tf + v * (0.075 + 0.10 * (1 - a.finishing)) * (1 + 0.5 * pr) * g();
    if (vz < 0) vz = 0;
    m.shot = { by: p, team: p.team, xg: pl.xg, t0: m.t, done: false };
    T.stats.shots++; T.stats.xg += sp === 'penalty' ? 0.76 : pl.xg;
  } else {
    const v = 24 + 4 * rng(), e = 38 * Math.PI / 180; ang = pl.ang; vh = v * Math.cos(e); vz = v * Math.sin(e);
  }
  b.owner = null;
  b.x = p.x + Math.cos(ang) * 0.6; b.y = p.y + Math.sin(ang) * 0.6; b.z = 0;
  b.vx = Math.cos(ang) * vh; b.vy = Math.sin(ang) * vh; b.vz = vz; b.lastTouch = p;
  p.noControlUntil = m.t + 0.45; p.setPiece = null; p.hands = false; p.protectedUntil = 0;
  const offs = [];
  if (pl.kind === 'pass' && sp !== 'throwin' && sp !== 'goalkick' && sp !== 'corner') for (const q of T.players) if (q !== p && q.x * d > T.offLine + 0.3) offs.push(q.id);
  m.pass = { from: p, to, kind: pl.kind, lofted: !!pl.lofted, t0: m.t, offs, type: pl.lofted ? 'air' : pl.feet ? 'pieds' : 'course' };
  if (pl.kind === 'pass') cnt(m, 'passe.' + m.pass.type); else cnt(m, pl.kind);
  if (m.corner && sp === 'corner') m.corner.until = m.t + 3;
  predict(m);
  react(m, to);
}

// ---------- contacts avec le ballon ----------
function deflect(m, p, keepFrac, spread) {
  const b = m.ball, sp = hyp(b.vx, b.vy), ang = Math.atan2(b.vy, b.vx) + spread * m.gauss(), v = sp * keepFrac + 1 + 2 * m.rng();
  b.vx = Math.cos(ang) * v + p.vx * 0.3; b.vy = Math.sin(ang) * v + p.vy * 0.3; b.vz = b.z > 0.3 ? Math.abs(b.vz) * 0.3 : 1.5 * m.rng();
  if (m.pass) passEnd(m, m.pass.from.team === p.team ? 'rate_partenaire' : 'devie');
  b.lastTouch = p; p.noControlUntil = m.t + 0.45; m.pass = null;
  react(m, null);
}
function offsideCheck(m, p) {
  const pass = m.pass;
  if (!pass || pass.kind !== 'pass' || pass.from.team !== p.team || pass.offs.indexOf(p.id) < 0) return false;
  passEnd(m, 'hors_jeu'); m.teams[p.team].stats.offsides++; log(m, 'offside', p.team, 'Hors-jeu de ' + p.name);
  setRestart(m, 'freekick', 1 - p.team, clamp(p.x, -P.HL + 1, P.HL - 1), clamp(p.y, -P.HW + 1, P.HW - 1), 8);
  return true;
}
function gainControl(m, p, z) {
  const b = m.ball, T = m.teams[p.team], a = p.a, pass = m.pass;
  if (offsideCheck(m, p)) return;
  const fromMate = pass && pass.from.team === p.team;
  if (pass && pass.kind === 'pass') { if (fromMate) { if (pass.from !== p) T.stats.passesOk++; } else T.stats.interceptions++; passEnd(m, fromMate ? 'ok' : 'interceptee'); }
  if (m.shot && !m.shot.done) m.shot.done = true;
  b.owner = p; b.z = 0; b.vz = 0; b.lastTouch = p;
  let delay = 0.18 + 0.34 * (1 - a.firstTouch) + (z > 0.4 ? 0.15 : 0);
  const pressed = oppDist(m.teams[1 - p.team], p.x, p.y) < 3;
  if (fromMate && m.rng() < 0.1 + 0.3 * a.passing * a.decisions + (pressed ? 0.3 : 0)) delay = 0.05;      // jeu en une touche
  p.controlReadyAt = m.t + delay; p.gotBallAt = m.t; p.firstTime = delay < 0.1;
  p.plan = null; p.hands = false; p.setPiece = null; p.protectedUntil = 0;
  p.nextThink = Math.min(p.nextThink, p.controlReadyAt);
  m.pass = null;
  react(m, null);
}
function catchBall(m, p) {
  const b = m.ball;
  if (m.pass && m.pass.kind === 'pass' && m.pass.from.team !== p.team) { m.teams[p.team].stats.interceptions++; passEnd(m, 'gardien'); }
  if (m.shot && !m.shot.done) m.shot.done = true;
  b.owner = p; b.lastTouch = p; p.hands = true; p.plan = null; p.setPiece = null;
  p.holdUntil = m.t + 2.5 + 2.5 * m.rng(); p.protectedUntil = p.holdUntil + 4; p.controlReadyAt = m.t; p.nextThink = m.t;
  m.pass = null;
  react(m, null);
}
function keeperSave(m, p, z, stretch, sp3) {
  const b = m.ball, T = m.teams[p.team], a = p.a, rng = m.rng, shot = m.shot;
  const pStop = clamp(0.995 - 0.33 * stretch * stretch * (1.5 - a.reflexes) - (z > 1.9 ? 0.1 : 0), 0.5, 0.995);
  if (rng() >= pStop) { const sh = m.shot; deflect(m, p, 0.6, 0.35); m.shot = sh; p.noControlUntil = m.t + 0.8; return; }     // touché, pas arrêté
  shot.done = true; m.teams[shot.team].stats.onTarget++; T.stats.saves++;
  if (sp3 < 15 || rng() < 0.2 + 0.5 * a.handling - 0.35 * stretch) { log(m, 'save', p.team, 'Tir de ' + shot.by.name + ', arrêt de ' + p.name); return catchBall(m, p); }
  log(m, 'save', p.team, 'Tir de ' + shot.by.name + ', parade de ' + p.name);
  const sgn = b.y >= p.y ? 1 : -1, ang = Math.atan2(sgn * (0.6 + 0.9 * rng()), T.dir * (-0.3 + 1.2 * rng())), v = 5 + 0.25 * sp3 + 3 * rng();
  b.vx = Math.cos(ang) * v; b.vy = Math.sin(ang) * v; b.vz = 1 + 3 * rng(); b.lastTouch = p; p.noControlUntil = m.t + 0.7; m.pass = null;
  react(m, null);
}
function header(m, p0, z) {
  const b = m.ball, rng = m.rng, pass = m.pass;
  let p = p0;
  for (const o of m.teams[1 - p.team].players) {                          // duel aérien
    if (o.stunUntil > m.t || o.role === 'GK' || hyp(o.x - b.x, o.y - b.y) > 1.5) continue;
    if (rng() > clamp(0.5 + 0.6 * (p.a.heading - o.a.heading) + (pass && pass.to === p ? 0.08 : 0), 0.15, 0.85)) p = o;
    break;
  }
  if (offsideCheck(m, p)) return;
  const T = m.teams[p.team], d = T.dir, a = p.a, gx = P.HL * d, dGoal = hyp(gx - p.x, p.y), rx = p.x * d;
  if (pass && pass.kind === 'pass') { if (pass.from.team === p.team) T.stats.passesOk++; else T.stats.interceptions++; passEnd(m, pass.from.team === p.team ? 'ok' : 'interceptee'); }
  b.lastTouch = p; p.noControlUntil = m.t + 0.6;
  let ang, v, vz, kind = 'clear', to = null;
  if (dGoal < 15 && rx > 36) {                                            // tête au but
    ang = Math.atan2((rng() - 0.5) * 2 * (P.GOAL_HW - 0.5) - p.y, gx - p.x) + (0.10 + 0.14 * (1 - a.heading)) * m.gauss();
    v = 11 + 5 * rng(); vz = -1 + 3 * rng(); kind = 'shot';
    const xg = clamp(0.4 * baseXg(T, p.x, p.y), 0.01, 0.4);
    m.shot = { by: p, team: p.team, xg, t0: m.t, done: false }; T.stats.shots++; T.stats.xg += xg;
  } else if (rx < -22) {                                                  // dégagement de la tête, parfois en corner
    ang = Math.atan2((p.y >= 0 ? 0.7 : -0.7) * d, rx < -44 && rng() < 0.3 ? -0.5 * d : d) + 0.35 * m.gauss(); v = 11 + 4 * rng(); vz = 4 + 2 * rng();
  } else {                                                                // remise
    let bd = 99;
    for (const q of T.players) { if (q === p || q.role === 'GK') continue; const dd = hyp(q.x - p.x, q.y - p.y); if (dd > 4 && dd < 20 && dd < bd) { bd = dd; to = q; } }
    if (to) { ang = Math.atan2(to.y - p.y, to.x - p.x) + 0.22 * m.gauss(); v = Math.min(14, groundSpeedFor(bd, 3) * 0.9); vz = 1; kind = 'pass'; T.stats.passes++; }
    else { ang = Math.atan2(0, d) + 0.5 * m.gauss(); v = 9; vz = 3; }
  }
  b.vx = Math.cos(ang) * v; b.vy = Math.sin(ang) * v; b.vz = vz;
  m.pass = { from: p, to, kind, lofted: false, t0: m.t, offs: [], type: 'tete' };
  react(m, to);
}

function touch(m, p, z, stretch) {
  const b = m.ball, T = m.teams[p.team], a = p.a, rng = m.rng, pass = m.pass, shot = m.shot;
  const keeper = p.role === 'GK' && inOwnBox(T, p.x, p.y);
  const sp3 = Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz), vrel = hyp(b.vx - p.vx, b.vy - p.vy);
  const fromMate = pass && pass.from.team === p.team;
  if (shot && !shot.done && shot.team !== p.team) {                       // tir adverse
    if (keeper) return keeperSave(m, p, z, stretch, sp3);
    if (rng() < 0.5) { shot.done = true; T.stats.blocks++; log(m, 'block', p.team, 'Tir de ' + shot.by.name + ' contré par ' + p.name); deflect(m, p, 0.5, 1.0); }
    else p.noControlUntil = m.t + 0.3;
    return;
  }
  if (pass && m.t - pass.t0 < 0.22 && !fromMate && sp3 > 8 && !keeper) {   // ballon tout juste frappé : pas le temps de réagir
    if (rng() < 0.3) deflect(m, p, 0.4, 0.9); else p.noControlUntil = m.t + 0.25;
    return;
  }
  if (keeper && !(fromMate && pass.kind === 'pass')) {                    // le gardien s'en saisit
    if (rng() < clamp(0.97 - 0.012 * Math.max(0, sp3 - 12) - (z > 1.8 ? 0.08 : 0), 0.5, 0.99)) { if (!offsideCheck(m, p)) catchBall(m, p); } else deflect(m, p, 0.3, 1.0);
    return;
  }
  if (z > 1.25) return header(m, p, z);
  let vOk = 11 + 8 * a.firstTouch; if (!(pass && pass.to === p)) vOk -= fromMate ? 2 : 6;
  let pc = 1 - clamp((vrel - vOk) / 14, 0, 0.92) - 0.008 - 0.02 * (1 - a.firstTouch) - (z > 0.45 ? 0.12 : 0);
  if (oppDist(m.teams[1 - p.team], p.x, p.y) < 1.5) pc -= 0.06;
  if (rng() < pc) gainControl(m, p, z); else deflect(m, p, 0.3, 0.9);
}

function resolveFreeBall(m) {
  const b = m.ball, sx = b.x - b.px, sy = b.y - b.py, L2 = sx * sx + sy * sy, fast = L2 > (15 * DT) * (15 * DT);
  let best = null, bs = 1e9, bz = 0, bd = 0;
  for (const p of m.players) {
    if (p.stunUntil > m.t || p.noControlUntil > m.t) continue;
    const keeper = p.role === 'GK' && inOwnBox(m.teams[p.team], p.x, p.y);
    const R = keeper ? 1.3 : fast ? 0.65 : 0.85, zMax = keeper ? 2.6 : 2.3;
    const u = L2 > 1e-9 ? clamp(((p.x - b.px) * sx + (p.y - b.py) * sy) / L2, 0, 1) : 0;
    const dd = hyp(p.x - b.px - sx * u, p.y - b.py - sy * u), z = b.pz + (b.z - b.pz) * u;
    if (dd > R || z > zMax) continue;
    let s = u * Math.sqrt(L2) + dd * 0.6 + 0.3 * m.rng();
    if (m.pass && m.pass.to === p) s -= 0.4;
    if (s < bs) { bs = s; best = p; bz = z; bd = L2 > 1e-9 ? Math.min(1, Math.abs((p.x - b.px) * sy - (p.y - b.py) * sx) / Math.sqrt(L2) / R) : dd / R; }
  }
  if (best) touch(m, best, bz, bd);
}

function resolveTackles(m) {
  const b = m.ball, c = b.owner, rng = m.rng;
  if (c.hands || c.protectedUntil > m.t) return;
  for (const o of m.teams[1 - c.team].players) {
    if (o.stunUntil > m.t || o.tackleReadyAt > m.t) continue;
    if (hyp(o.x - b.x, o.y - b.y) > 1.25) continue;
    const T = m.teams[o.team], keeper = o.role === 'GK' && inOwnBox(T, o.x, o.y);
    const rx = o.x - c.x, ry = o.y - c.y, closing = (c.vx * rx + c.vy * ry) / (hyp(rx, ry) || 1);
    const lam = closing > 2.5 || (keeper && o.intent.type === 'claim') ? 5 : (o.intent.type === 'press' || keeper ? 0.6 : 0.25) * (0.6 + 0.8 * o.a.aggression) * (hyp(c.x + P.HL * T.dir, c.y) < 25 ? 2.2 : 1);
    if (rng() > lam * DT) continue;
    const front = (rx * Math.cos(c.face) + ry * Math.sin(c.face)) / (hyp(rx, ry) || 1);      // 1 : de face, −1 : dans le dos
    const pWin = clamp(0.40 + 0.55 * (o.a.tackling - c.a.dribbling) + 0.12 * front + (m.t < c.controlReadyAt ? 0.15 : 0) + (keeper ? 0.2 : 0), 0.12, 0.85);
    const pFoul = (0.09 + 0.13 * o.a.aggression) * (front < -0.2 ? 1.6 : 1) * (keeper ? 0.4 : 1) * (inOwnBox(T, c.x, c.y) ? 0.3 : 1);
    const r = rng();
    o.tackleReadyAt = m.t + 1.0 + 0.6 * rng();
    cnt(m, 'tacle.tente');
    if (r < pFoul) {
      T.stats.fouls++;
      const pen = inOwnBox(T, c.x, c.y);
      log(m, 'foul', o.team, 'Faute de ' + o.name + ' sur ' + c.name + (pen ? ' — penalty !' : ''));
      if (pen) setRestart(m, 'penalty', c.team, -(P.HL - P.SPOT) * T.dir, 0, 25);
      else setRestart(m, 'freekick', c.team, clamp(c.x, -P.HL + 1, P.HL - 1), clamp(c.y, -P.HW + 1, P.HW - 1), 9);
    } else if (r < pFoul + pWin) {
      T.stats.tackles++; c.stunUntil = m.t + 0.35; c.plan = null; c.setPiece = null;
      if (keeper) catchBall(m, o);
      else if (rng() < 0.5) { b.owner = o; b.lastTouch = o; o.controlReadyAt = m.t + 0.35; o.gotBallAt = m.t; o.firstTime = false; o.plan = null; o.nextThink = m.t + 0.35; m.pass = null; react(m, null); }
      else { const ang = o.face + 0.8 * m.gauss(), v = 4 + 4 * rng(); b.owner = null; b.vx = Math.cos(ang) * v; b.vy = Math.sin(ang) * v; b.vz = 0; b.lastTouch = o; o.noControlUntil = m.t + 0.25; c.noControlUntil = m.t + 0.5; m.pass = null; react(m, null); }
    } else o.stunUntil = m.t + 0.4 + 0.35 * rng();          // tacle manqué : le défenseur est éliminé un instant
    return;
  }
}

// ---------- arrêts de jeu ----------
function pickTaker(m, type, team, x, y) {
  const T = m.teams[team], ps = T.players, ry = y * T.dir;
  if (type === 'kickoff') return ps[9];
  if (type === 'goalkick') return ps[0];
  if (type === 'corner') return ry < 0 ? ps[5] : ps[8];
  if (type === 'penalty') { let b = ps[9]; for (const p of ps) if (p.role !== 'GK' && p.a.finishing > b.a.finishing) b = p; return b; }
  let best = null, bd = 1e9;
  const cands = type === 'throwin' ? (ry < 0 ? [ps[1], ps[5]] : [ps[4], ps[8]]) : ps;
  for (const p of cands) { let dd = hyp(p.x - x, p.y - y); if (p.role === 'GK' && !inOwnBox(T, x, y)) dd += 99; if (dd < bd) { bd = dd; best = p; } }
  return best;
}
function setRestart(m, type, team, x, y, delay) {
  passEnd(m, 'sortie'); cnt(m, 'arret.' + type);
  m.mode = 'dead'; m.ball.owner = null; m.pass = null; m.shot = null;
  for (const p of m.players) { p.plan = null; p.setPiece = null; p.hands = false; if (p.intent.type === 'run') p.intent.until = 0; p.nextThink = Math.min(p.nextThink, m.t + 0.2 + 0.5 * m.rng()); }
  m.restart = { type, team, x, y, readyAt: m.t + delay, deadline: m.t + delay + 14, ballAt: m.t + 1, placed: false, taker: pickTaker(m, type, team, x, y) };
  m.corner = type === 'corner' ? { team, side: Math.sign(y) || 1, until: Infinity } : null;
}
function runRestart(m) {
  const R = m.restart, b = m.ball, k = R.taker;
  if (!R.placed) {
    if (m.t < R.ballAt) {                                   // le ballon finit sa course (dans le filet, hors du terrain)
      ballStep(b, DT);
      if (Math.abs(b.x) > P.HL || Math.abs(b.y) > P.HW) {             // filet, panneaux : le ballon s'arrête vite
        const inGoal = Math.abs(b.x) > P.HL && Math.abs(b.y) < P.GOAL_HW + 0.3 && b.z < P.GOAL_H;
        b.vx *= 0.8; b.vy *= 0.8;
        b.x = clamp(b.x, -P.HL - (inGoal ? 2.2 : 3.5), P.HL + (inGoal ? 2.2 : 3.5)); b.y = inGoal ? clamp(b.y, -P.GOAL_HW, P.GOAL_HW) : clamp(b.y, -P.HW - 2.8, P.HW + 2.8);
      }
      return;
    }
    b.x = b.px = R.x; b.y = b.py = R.y; b.z = b.pz = 0; b.vx = b.vy = b.vz = 0; R.placed = true;
  }
  const near = hyp(k.x - b.x, k.y - b.y) < 1.2;
  if (!(m.t >= R.readyAt && near) && m.t < R.deadline) return;
  if (!near) { k.x = b.x; k.y = b.y; k.vx = k.vy = 0; }
  m.mode = 'play'; b.owner = k; b.lastTouch = k;
  k.setPiece = R.type; k.protectedUntil = m.t + 8; k.controlReadyAt = m.t + 0.4 + 0.5 * m.rng(); k.gotBallAt = -9; k.firstTime = false; k.hands = false; k.plan = null; k.nextThink = m.t;
  k.face = Math.atan2(-k.y, -k.x || m.teams[k.team].dir);
  m.restart = null;
}
function goal(m, att) {
  const b = m.ball, T = m.teams[att], s = m.shot;
  T.score++; T.stats.goals++;
  let scorer = b.lastTouch;
  if (s && !s.done) { s.done = true; if (s.team === att) { scorer = s.by; T.stats.onTarget++; } }
  const sc = ' (' + m.teams[0].score + '-' + m.teams[1].score + ')';
  log(m, 'goal', att, scorer && scorer.team !== att ? 'But contre son camp de ' + scorer.name + sc : 'BUT pour les ' + T.name + ' ! ' + (scorer ? scorer.name : '') + sc);
  setRestart(m, 'kickoff', 1 - att, 0, 0, 22);
  m.restart.ballAt = m.t + 3;
}
function checkBounds(m) {
  const b = m.ball;
  if (b.owner && b.owner.setPiece) return;
  const ax = Math.abs(b.x), ay = Math.abs(b.y);
  if (ax <= P.HL && ay <= P.HW) return;
  const last = b.lastTouch;
  let u = 1, goalLine = false;
  if (ax > P.HL) { const pax = Math.abs(b.px); u = pax >= P.HL ? 0 : (P.HL - pax) / (ax - pax); goalLine = true; }
  if (ay > P.HW) { const pay = Math.abs(b.py), ut = pay >= P.HW ? 0 : (P.HW - pay) / (ay - pay); if (!goalLine || ut < u) { u = ut; goalLine = false; } }
  const cx = b.px + (b.x - b.px) * u, cy = b.py + (b.y - b.py) * u, cz = b.pz + (b.z - b.pz) * u;
  if (goalLine) {
    const end = b.x > 0 ? 1 : -1, att = end > 0 ? 0 : 1, def = 1 - att;
    if (Math.abs(cy) < P.GOAL_HW && cz < P.GOAL_H) return goal(m, att);
    const s = m.shot;
    if (s && !s.done) { s.done = true; log(m, 'shot', s.team, 'Tir de ' + s.by.name + (cz >= P.GOAL_H && Math.abs(cy) < P.GOAL_HW ? ' au-dessus' : ' à côté')); }
    const side = cy >= 0 ? 1 : -1;
    if (last && last.team === def) { m.teams[att].stats.corners++; log(m, 'corner', att, 'Corner pour les ' + m.teams[att].name); setRestart(m, 'corner', att, end * (P.HL - 0.4), side * (P.HW - 0.4), 14); }
    else setRestart(m, 'goalkick', def, end * (P.HL - P.SIX_D), side * 5, 12);
  } else {
    setRestart(m, 'throwin', last ? 1 - last.team : 0, clamp(cx, -P.HL + 1, P.HL - 1), (b.y > 0 ? 1 : -1) * (P.HW - 0.25), 7);
  }
}

// ---------- déplacement ----------
function speedFor(p, dd, urg) {
  if (dd < 0.6) return 0;
  const e = clamp(urg * (0.8 + 0.4 * p.a.workRate), 0, 1);
  const cap = e > 0.8 ? topSpeed(p) : e > 0.5 ? RUN * (0.9 + 0.2 * p.a.pace) : JOG;
  return clamp(dd / lerp(6, 0.8, e), WALK, cap);          // plus c'est urgent, moins on se donne de temps pour y être
}
function act(m, p) {
  const b = m.ball, it = p.intent, T = m.teams[p.team], d = T.dir, top = topSpeed(p), owner = b.owner === p;
  let tx = it.tx, ty = it.ty, sp = 0, acc = p.acc, dec = 7.5, brake = true, cap = top;
  if (p.stunUntil > m.t) { tx = p.x; ty = p.y; }
  else switch (it.type) {
    case 'chase': case 'receive': case 'claim': {
      const ic = !b.owner && m.mode === 'play' ? m.icpt[p.id] : null;
      if (ic) { tx = ic.x; ty = ic.y; } else { tx = b.x; ty = b.y; }
      sp = top; brake = false;
      if (it.type === 'receive' && ic) {                       // le ballon lui est destiné : il vient à sa rencontre sans se précipiter
        let rival = 99; for (const o of m.teams[1 - p.team].players) rival = Math.min(rival, m.icpt[o.id].t);
        if (rival > ic.t + 0.5) { sp = Math.min(top, Math.max(JOG, hyp(tx - p.x, ty - p.y) / Math.max(0.2, ic.t - 0.15))); brake = true; }
      }
      break;
    }
    case 'press': {
      const c = b.owner && b.owner.team !== p.team ? b.owner : null, th = c || threat(m);
      const gx = -P.HL * d; let ux = gx - th.x, uy = -th.y; const n = hyp(ux, uy) || 1; ux /= n; uy /= n;
      const engage = c && (n < 24 || hyp(c.vx, c.vy) < 1.5);
      const dd = hyp(th.x - p.x, th.y - p.y), off = dd > 6 ? 2.5 : dd > 3 ? 2 : engage ? 0.6 : 1.7, lead = c ? Math.min(dd / 8, 0.5) : 0;
      tx = th.x + (c ? c.vx * lead : 0) + ux * off; ty = th.y + (c ? c.vy * lead : 0) + uy * off;
      if (engage && dd < 3 && hyp(c.vx, c.vy) < 1.5) { tx = b.x; ty = b.y; }                // il protège son ballon : on le contourne
      sp = dd > 5 || !c ? top : Math.max(hyp(c.vx, c.vy) + 1.5, 4);      // sprinte puis temporise à l'approche
      brake = !c; break;
    }
    case 'run': {
      sp = top; brake = false; break;
    }
    case 'dribble': tx = p.x + it.dx * 6; ty = p.y + it.dy * 6; sp = Math.min(it.speed, top * 0.9); brake = false; break;
    case 'toBall': sp = RUN; break;
    case 'save': {
      if (m.t >= p.saveAt) { const c = !b.owner ? goalThreat(m, p) : null; if (c) { it.tx = c.x; it.ty = c.y; } tx = it.tx; ty = it.ty; sp = 6.8; acc = 18; dec = 18; cap = 7; }
      else { tx = p.x; ty = p.y; }
      break;
    }
    case 'control': { const v = hyp(p.vx, p.vy); tx = p.x + p.vx; ty = p.y + p.vy; sp = Math.min(v, 2.5); brake = false; break; }
    case 'kick': tx = p.x + Math.cos(p.face); ty = p.y + Math.sin(p.face); sp = Math.min(hyp(p.vx, p.vy), 1.5); brake = false; break;
    case 'hold': tx = p.x; ty = p.y; break;
    default: sp = speedFor(p, hyp(tx - p.x, ty - p.y), it.urg);
  }
  const dx = tx - p.x, dy = ty - p.y, dist = hyp(dx, dy);
  let vdx = 0, vdy = 0;
  if (dist > (it.type === 'save' ? 0.08 : 0.25) && sp > 0) { const v = brake ? Math.min(sp, Math.sqrt(0.93 * dec * dist)) : sp; vdx = dx / dist * v; vdy = dy / dist * v; }
  let ex = vdx - p.vx, ey = vdy - p.vy; const e = hyp(ex, ey), cur = hyp(p.vx, p.vy);
  const amax = (ex * p.vx + ey * p.vy < 0 ? dec : acc * (1 - 0.55 * Math.min(1, cur / top))) * DT;      // on freine plus vite qu'on n'accélère
  if (e > amax) { ex *= amax / e; ey *= amax / e; }
  p.vx += ex; p.vy += ey;
  let ns = hyp(p.vx, p.vy); if (ns > cap) { p.vx *= cap / ns; p.vy *= cap / ns; ns = cap; }
  p.x += p.vx * DT; p.y += p.vy * DT;
  const mg = owner ? -0.6 : 1.5;
  p.x = clamp(p.x, -P.HL - mg, P.HL + mg); p.y = clamp(p.y, -P.HW - mg, P.HW + mg);
  // orientation du corps
  const shield = owner && it.type === 'hold' && it.shield != null;
  const fa = p.plan ? p.plan.ang : shield ? it.shield : (ns > 1.4 && it.type !== 'press') ? Math.atan2(p.vy, p.vx) : Math.atan2(b.y - p.y, b.x - p.x);
  if (!(owner && ns <= 1.4 && !p.plan && !shield)) p.face += clamp(angDiff(fa, p.face), -8 * DT, 8 * DT);
  // fatigue
  const r = ns / p.top; p.stam = clamp(p.stam + (ns < 2.2 ? 0.0012 : -0.0045 * r * r * r * (1.3 - 0.5 * p.a.stamina)) * DT, 0.3, 1);
  p.dist += ns * DT;
}
function separate(m) {
  const ps = m.players;
  for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
    const a = ps[i], b = ps[j], dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy;
    if (d2 > 0.49 || d2 < 1e-6) continue;
    const dd = Math.sqrt(d2), k = (0.7 - dd) / 2 / dd;
    a.x -= dx * k; a.y -= dy * k; b.x += dx * k; b.y += dy * k;
  }
}
function moveBall(m) {
  const b = m.ball, o = b.owner;
  if (o) {
    const off = o.hands ? 0.35 : 0.5 + 0.06 * hyp(o.vx, o.vy);
    b.x += (o.x + Math.cos(o.face) * off - b.x) * 0.45; b.y += (o.y + Math.sin(o.face) * off - b.y) * 0.45;
    b.x = clamp(b.x, -P.HL + 0.1, P.HL - 0.1); b.y = clamp(b.y, -P.HW + 0.1, P.HW - 0.1);
    b.z = o.hands ? 1.1 : 0; b.vx = o.vx; b.vy = o.vy; b.vz = 0;
  } else if (m.mode === 'play') ballStep(b, DT);
}

// ---------- un pas de simulation ----------
function step(m) {
  if (m.mode === 'over') return;
  const b = m.ball;
  for (const p of m.players) { p.px = p.x; p.py = p.y; }
  b.px = b.x; b.py = b.y; b.pz = b.z;
  m.t += DT; m.tick++;
  if (!b.owner && m.mode === 'play') predict(m);
  updateContext(m);
  if (m.mode === 'dead') runRestart(m);
  if (b.owner && b.owner.plan && m.t >= b.owner.plan.at) executePlan(m, b.owner);
  for (const p of m.players) if (m.t >= p.nextThink) think(m, p);
  for (const p of m.players) act(m, p);
  separate(m);
  moveBall(m);
  if (m.mode === 'play') {
    if (b.owner) resolveTackles(m); else resolveFreeBall(m);
    if (m.mode === 'play') checkBounds(m);
  }
  if (m.mode === 'play') { m.playT += DT; if (m.poss >= 0) m.teams[m.poss].stats.possT += DT; if (b.owner) cnt(m, 'temps.balle_au_pied', DT); }
  if (m.t >= m.duration) { m.mode = 'over'; log(m, 'end', -1, 'Fin du match : ' + m.teams[0].name + ' ' + m.teams[0].score + ' - ' + m.teams[1].score + ' ' + m.teams[1].name); }
}

return { createMatch, step, DT, PITCH: P, valueAt };
});
