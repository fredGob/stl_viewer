# Moteur de match de football

## Le but

Frédéric veut créer un jeu d'entraîneur de football centré sur la tactique : pas de simulation du monde du foot ni du temps qui passe, seulement un match où le joueur gagne par ses choix tactiques. Il faut pour cela un moteur de match réaliste, où chaque footballeur réfléchit par lui-même et ne ressemble pas à un robot.

Étape actuelle (8 octobre 2026) : un moteur qui simule 10 minutes de match, deux équipes en 4-4-2, toutes les consignes neutres. Il n'y a encore aucune consigne tactique réglable.

## Comment parler à Frédéric

Il a dit plusieurs fois ne pas comprendre ce que je faisais pendant ce travail. Donc : phrases simples, pas de jargon, dire régulièrement où on en est, et tenir ce fichier à jour (tests, réussites, échecs) à chaque séance.

## Regarder un match

Le fichier à ouvrir est `match.html` : il contient tout et s'ouvre dans n'importe quel navigateur.

Depuis Cloud Shell, deux façons :

- le télécharger : `cloudshell download ~/match-engine/match.html`, puis double-clic sur le fichier ;
- ou le servir : `cd ~/match-engine && python3 -m http.server 8080`, puis « Aperçu sur le Web », port 8080, et ouvrir `match.html`.

Dans la page : pause, vitesse ×1 à ×8, clic sur un joueur pour lire ce qu'il est en train de faire, case à cocher pour voir où chaque joueur veut aller, numéro de match pour rejouer exactement le même.

## Les fichiers

| Fichier | Rôle |
|---|---|
| `engine.js` | Le moteur : joueurs, ballon, règles, décisions. Aucun affichage. |
| `render.js` | Le dessin du terrain vu de dessus. |
| `index.html` | La page (boutons, statistiques, fil du match). |
| `build.js` | Assemble les trois en un seul fichier `match.html`. |
| `sim.js` | Simule beaucoup de matchs sans affichage et donne les moyennes. |
| `check.js` | Vérifie que le moteur ne déraille pas. |
| `tools/` | Outils de contrôle : images du match, test de la page, mesures détaillées. |

## Comment le moteur fonctionne

Le temps avance par pas de 0,05 seconde. À chaque pas :

1. **L'équipe** donne à chaque joueur une position de référence, qui dépend de l'endroit où est le ballon et de qui l'a. C'est un repère, pas un ordre.
2. **Chaque joueur réfléchit** à son propre rythme (toutes les 0,2 à 0,4 seconde, jamais tous en même temps) et choisit quoi faire : presser, marquer, se démarquer, faire un appel, aller au ballon.
3. **Le porteur du ballon** note toutes ses options (chaque passe possible, conduire le ballon dans 9 directions, tirer, garder, dégager) et prend la meilleure, avec une part d'erreur qui dépend de ses qualités et de la pression.
4. **Les gestes sont imprécis** : une passe ou un tir part avec un écart qui dépend du joueur, de la distance et de la pression.
5. **Le ballon suit une physique simple** : il roule, ralentit, vole, rebondit.

Chaque joueur a 20 qualités tirées au hasard (vitesse, passe, lucidité, goût du risque…), donc deux joueurs dans la même situation ne décident pas pareil.

## Les tests

À relancer après toute modification de `engine.js` :

```
node check.js 200     # le moteur ne déraille pas
node sim.js 300       # les moyennes ressemblent au football
node build.js         # refait match.html
```

Tests plus poussés (une seule fois : `cd tools && npm install`) :

```
node tools/page.js                         # la vraie page fonctionne-t-elle (boutons, clic, stats) ?
node tools/snap.js 5 img.png 60,62,64,66   # images du match n°5 à ces instants, à regarder
node tools/zones.js 20                     # dans quelle partie du terrain se joue le match
node tools/shots.js 100                    # d'où partent les tirs et ce qu'ils deviennent
```

### Ce que vérifie `check.js`

Sur chaque match : aucune valeur aberrante, aucun joueur trop rapide, ballon jamais loin du terrain, aucune situation figée plus de 25 secondes, aucun arrêt de jeu de plus de 40 secondes. Et la même graine redonne exactement le même match.

## État mesuré

Mesures du 8 octobre 2026, sur 300 matchs de 10 minutes (`node sim.js 300`), les deux équipes ensemble.

| Par match de 10 min | Simulé | Vrai football | Verdict |
|---|---|---|---|
| Buts | 0,49 | 0,30 | un peu haut |
| Tirs | 4,2 | 2,8 | un peu haut |
| Tirs cadrés | 2,2 | 0,9 | trop haut |
| Occasions (buts attendus) | 0,47 | 0,30 | un peu haut |
| Passes | 150 | 100 | un peu haut |
| Passes réussies | 81,7 % | 80 à 85 % | bon |
| Tacles réussis | 9,0 | 3,7 | trop haut |
| Fautes | 4,6 | 2,6 | trop haut |
| Corners | 0,58 | 1,1 | trop bas |
| Hors-jeu | 0,18 | 0,44 | trop bas |
| Temps de jeu effectif | 79 % | 55 à 60 % | trop haut |
| Possession des Bleus | 50,8 % | 50 % | bon |
| Distance par joueur | 1 326 m | 1 170 m | correct |

Deux réserves sur ce tableau :

- La colonne « vrai football » vient de ma mémoire (ordres de grandeur du football professionnel), pas d'un jeu de données vérifié.
- Le ballon est en jeu 79 % du temps contre 55 à 60 % en vrai, parce que les arrêts de jeu sont courts. Tous les compteurs par match sont donc gonflés d'environ 40 %. À temps de jeu égal, les buts, les tirs et les passes sont proches de la réalité.

Autres mesures :

- **Allure des joueurs** : marche 55 %, trot 29 %, course 11 %, sprint 6 %. Proche de ce qu'on observe en vrai.
- **Où se joue le match** : 17 % dans le tiers défensif, 60 % au milieu, 23 % dans le tiers offensif.
- **Réussite des tirs selon la distance** (100 matchs) : 15 % à moins de 8 m, 18 % entre 8 et 12 m, 10 % entre 12 et 16,5 m, 3 % entre 16,5 et 22 m, 2 % au-delà.
- **Score** : 60 % des matchs de 10 minutes finissent à 0-0, ce qui est normal avec un demi-but par match.

## Ce qui est vérifié, ce qui ne l'est pas

Vérifié :

- 200 matchs sans anomalie (`check.js`).
- La page tourne sans erreur dans un faux navigateur : horloge, score, pause, vitesse, clic sur un joueur, statistiques, fil du match, rejouer un match (`tools/page.js`).
- Le dessin est correct : je l'ai rendu en image et regardé (terrain, joueurs, ballon en l'air, étiquette du joueur choisi).
- Sur des images fixes, les situations ressemblent à du football : bloc défensif, équipe étagée en attaque, corner avec les joueurs dans la surface.

Pas vérifié :

- **La page n'a jamais été ouverte dans un vrai navigateur.** Il n'y en a pas sur cette machine.
- **Personne n'a regardé le match en mouvement.** Je n'ai vu que des images fixes. Je ne peux donc pas dire si les joueurs ont encore l'air de robots : c'est à Frédéric de regarder et de le dire.

## Journal des essais

Tout s'est passé le 8 octobre 2026. Chaque ligne : ce que j'ai observé, ce que j'ai changé, le résultat.

| N° | Constat | Changement | Résultat |
|---|---|---|---|
| 1 | Premier jet : 20 tacles et 10 fautes par match, 72 % de passes réussies, 1 but par match | — | Échec : jeu haché |
| 2 | Ballon trop freiné, passes trop molles, défenseurs qui se jettent | Frottement réaliste, passes plus appuyées, tacles plus rares | Fautes à 2,5 (bon), mais 37 longs ballons par match |
| 3 | Trop de longs ballons | Long ballon moins rentable, receveur qui vient au ballon | 85 % de passes réussies, mais moins d'un tir par match |
| 4 | Les équipes restent dans leur camp (72 % du temps) | Le porteur surestimait la capacité des adversaires à couper ses passes : corrigé | Mieux, mais encore 68 % dans leur camp |
| 5 | Toujours pas de progression | Valeur des positions revue, bloc défensif plus haut, équipe plus étagée en attaque | 2,3 tirs par match, mais passes réussies retombées à 73 % |
| 6 | Le porteur choisissait presque au hasard dans son camp | Choix resserré sur les meilleures options | Échec : tout le monde dribble, 9 tirs et 3 buts par match |
| 7 | Trop de dribbles | Dribble sous pression plus risqué, duels modélisés | Bug révélé : un joueur reste planté près du poteau de corner |
| 8 | Joueur immobile balle au pied | Garder le ballon coûte de plus en plus ; pressing obligatoire dans son tiers | Répartition du jeu correcte sur le terrain |
| 9 | 35 duels par match | Duel seulement si le porteur fonce sur le défenseur | Tacles et fautes corrects, mais buts de 30 mètres |
| 10 | Buts de loin | Bug trouvé : le gardien plongeait trop loin et dépassait le ballon. Corrigé | Tirs de loin arrêtés (2 à 4 % de buts) |
| 11 | Presque aucune passe en profondeur (0,1 par match) | Bug trouvé : ces passes mettaient 3 secondes à arriver. Corrigé | 6,7 par match, 40 % réussies |
| 12 | Encore trop de buts | Gardien qui ferme l'angle, recule sous un lob, sort dans les pieds ; défenseurs qui suivent les appels | Buts à 0,5 par match |
| 13 | `check.js` signale un joueur qui garde le ballon 25 secondes | Le presseur va au contact, un deuxième défenseur vient aider | 200 matchs sans anomalie |

## Ce qui ne va pas encore

- Trop de tacles réussis et de fautes, trop peu de corners et de hors-jeu (voir le tableau).
- Trop de tirs cadrés : les joueurs visent trop bien.
- Les arrêts de jeu sont trop courts, et le ballon saute d'un coup à l'endroit de la remise en jeu.
- Les réglages ont été faits à la main, en 13 passes, sur des moyennes. Changer un nombre en déplace d'autres : toujours remesurer.

## Ce qui n'existe pas encore

- Aucune consigne tactique réglable : hauteur du bloc, largeur, pressing et tempo sont des nombres fixes dans `engine.js`.
- Une seule formation (4-4-2), deux équipes de même niveau tirées au hasard.
- Pas de cartons, de remplacements, de blessures, de mi-temps, de mur sur coup franc, de règle de l'avantage.
- Touches jouées comme des passes courtes, pas de pied fort, jeu de tête très simplifié.
- Vue de dessus en 2D seulement.
