// Simule des matchs sans affichage et affiche les statistiques moyennes.
// Usage : node sim.js [nombre de matchs] [première graine] [durée en secondes]
const E = require('./engine.js');

const n = +process.argv[2] || 100, seed0 = +process.argv[3] || 1, duration = +process.argv[4] || 600;
const keys = ['goals', 'shots', 'onTarget', 'xg', 'passes', 'passesOk', 'tackles', 'interceptions', 'blocks', 'fouls', 'corners', 'offsides', 'saves'];
const sum = {}; for (const k of keys) sum[k] = 0;
let play = 0, poss0 = 0, dist = 0, t0 = Date.now(), scores = {}, count = {};

for (let i = 0; i < n; i++) {
  const m = E.createMatch({ seed: seed0 + i, duration });
  while (m.mode !== 'over') E.step(m);
  for (const T of m.teams) for (const k of keys) sum[k] += T.stats[k];
  play += m.playT;
  poss0 += m.teams[0].stats.possT / (m.teams[0].stats.possT + m.teams[1].stats.possT || 1);
  for (const p of m.players) dist += p.dist;
  for (const k in m.count) count[k] = (count[k] || 0) + m.count[k];
  const sc = m.teams[0].score + '-' + m.teams[1].score; scores[sc] = (scores[sc] || 0) + 1;
  if (n === 1) for (const e of m.events) console.log(String(Math.floor(e.t / 60)).padStart(2, '0') + ':' + String(Math.floor(e.t % 60)).padStart(2, '0'), e.text);
}

const per = k => (sum[k] / n).toFixed(2);
// ordres de grandeur du football professionnel, ramenés à la durée simulée (les deux équipes ensemble)
const ref = { goals: 2.7, shots: 25, onTarget: 8.5, xg: 2.7, passes: 900, tackles: 33, interceptions: 20, blocks: 7, fouls: 23, corners: 10, offsides: 4, saves: 6 };
console.log(`\n${n} match(s) de ${duration} s — ${((Date.now() - t0) / n).toFixed(0)} ms par match\n`);
console.log('par match (2 équipes)   simulé    réel (ordre de grandeur)');
for (const k of keys) if (k !== 'passesOk') console.log('  ' + k.padEnd(20) + per(k).padStart(8) + '    ' + (ref[k] * duration / 5400).toFixed(2));
console.log('  passes réussies'.padEnd(22) + (100 * sum.passesOk / sum.passes).toFixed(1).padStart(7) + ' %    80 à 85 %');
console.log('  temps de jeu effectif'.padEnd(22) + (100 * play / (n * duration)).toFixed(1).padStart(6) + ' %    55 à 60 %');
console.log('  possession Bleus'.padEnd(22) + (100 * poss0 / n).toFixed(1).padStart(7) + ' %    50 %');
console.log('  distance par joueur'.padEnd(22) + (dist / (n * 22)).toFixed(0).padStart(7) + ' m    ' + (10500 * duration / 5400).toFixed(0) + ' m');
if (n > 1) console.log('\nscores les plus fréquents :', Object.entries(scores).sort((a, b) => b[1] - a[1]).slice(0, 6).map(e => e[0] + ' ×' + e[1]).join(', '));

if (process.env.DETAIL) { console.log('\ndétail (par match) :'); for (const k of Object.keys(count).sort()) console.log('  ' + k.padEnd(28) + (count[k] / n).toFixed(2).padStart(8)); }
