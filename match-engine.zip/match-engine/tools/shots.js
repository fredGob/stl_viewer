// Suit chaque tir : distance, issue, et ce que fait le gardien
const E = require('../engine.js');
const n = +process.argv[2] || 10, verbose = process.argv[3] === 'v';
const bins = [0, 8, 12, 16.5, 22, 28, 40], res = bins.map(() => ({ n: 0, goal: 0, save: 0, block: 0, off: 0, xg: 0 }));
const bin = d => { for (let i = bins.length - 1; i >= 0; i--) if (d >= bins[i]) return i; return 0; };
let shown = 0;
for (let i = 0; i < n; i++) {
  const m = E.createMatch({ seed: 500 + i }); let cur = null, ev = 0;
  while (m.mode !== 'over') {
    E.step(m);
    const s = m.shot;
    if (s && s !== cur) {
      cur = s; const T = m.teams[s.team], gk = m.teams[1 - s.team].players[0];
      s._d = Math.hypot(52.5 * T.dir - s.by.x, s.by.y); s._gk0 = { x: gk.x, y: gk.y }; s._b0 = { x: m.ball.x, y: m.ball.y, vx: m.ball.vx, vy: m.ball.vy, vz: m.ball.vz }; s._log = [];
      const r = res[bin(s._d)]; r.n++; r.xg += s.xg; s._r = r;
    }
    if (cur && !cur._end) {
      const gk = m.teams[1 - cur.team].players[0];
      if (cur._log.length < 40) cur._log.push(`${(m.t - cur.t0).toFixed(2)} ballon(${m.ball.x.toFixed(1)},${m.ball.y.toFixed(1)},z${m.ball.z.toFixed(1)}) gardien(${gk.x.toFixed(1)},${gk.y.toFixed(1)}) ${gk.intent.type}`);
      for (; ev < m.events.length; ev++) {
        const e = m.events[ev]; let k = null;
        if (e.kind === 'goal') k = 'goal'; else if (e.kind === 'save') k = 'save'; else if (e.kind === 'block') k = 'block'; else if (e.kind === 'shot') k = 'off';
        if (k && e.t >= cur.t0) { cur._r[k]++; cur._end = k;
          if (verbose && k === 'goal' && cur._d > 20 && shown < 2) { shown++; console.log(`\n--- BUT de ${cur._d.toFixed(1)} m (graine ${500 + i}, t=${cur.t0.toFixed(1)}) xg ${cur.xg.toFixed(3)}  gardien au départ (${cur._gk0.x.toFixed(1)},${cur._gk0.y.toFixed(1)})  tir v=(${cur._b0.vx.toFixed(1)},${cur._b0.vy.toFixed(1)},${cur._b0.vz.toFixed(1)})`); console.log(cur._log.join('\n')); }
          break; }
      }
      if (cur.done && !cur._end && m.t - cur.t0 > 4) cur._end = 'autre';
    } else ev = m.events.length;
  }
}
console.log('\ndistance      tirs/match   xG/tir   but %   arrêt %  contré %  hors cadre %');
res.forEach((r, i) => { if (r.n) console.log(`${String(bins[i]).padStart(5)} m et +   ${(r.n / n).toFixed(2).padStart(7)}     ${(r.xg / r.n).toFixed(3)}   ${(100 * r.goal / r.n).toFixed(0).padStart(4)}    ${(100 * r.save / r.n).toFixed(0).padStart(4)}     ${(100 * r.block / r.n).toFixed(0).padStart(4)}      ${(100 * r.off / r.n).toFixed(0).padStart(4)}`); });
