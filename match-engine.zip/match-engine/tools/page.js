// Fait tourner la vraie page match.html dans un faux navigateur : vérifie que l'interface fonctionne (boutons, clic, stats, fil du match)
const fs = require('fs'), { JSDOM } = require('jsdom'), { createCanvas } = require('@napi-rs/canvas');
const html = fs.readFileSync(__dirname + '/../match.html', 'utf8');
const errors = [];
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, beforeParse(w) {
  const real = createCanvas(1140, 750);
  w.HTMLCanvasElement.prototype.getContext = function () { return real.getContext('2d'); };
  w.HTMLCanvasElement.prototype.getBoundingClientRect = function () { return { left: 0, top: 0, width: 1140, height: 750 }; };
  w.addEventListener('error', e => errors.push(e.message));
  w.__canvas = real;
} });
const w = dom.window, d = w.document, $ = id => d.getElementById(id);
const wait = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  d.querySelector('[data-speed="8"]').click();
  await wait(2500);
  console.log('horloge :', $('clock').textContent, '| score :', $('goals').textContent, '| équipes :', $('name0').textContent, '/', $('name1').textContent);
  // clic sur le joueur n°9 bleu : on retrouve sa position à l'écran avec la même transformation que le dessin
  const s = Math.min(1140 / (2 * 57), 750 / (2 * 37.5));
  let found = false;
  for (let x = 200; x < 1000 && !found; x += 50) for (let y = 150; y < 650 && !found; y += 50) { $('pitch').onclick({ clientX: x, clientY: y }); await wait(60); if (!/Cliquez/.test($('player').textContent)) found = true; }
  await wait(400);
  console.log('fiche joueur :', $('player').textContent.replace(/\s+/g, ' ').slice(0, 150));
  $('intents').checked = true;
  $('play').click(); await wait(200); const t1 = $('clock').textContent; await wait(400); console.log('pause tient :', t1 === $('clock').textContent, '(bouton : ' + $('play').textContent + ')');
  $('play').click(); await wait(2500);
  console.log('stats :', [...$('stats').querySelectorAll('tr')].slice(0, 6).map(r => r.textContent).join(' | '));
  console.log('fil du match (' + $('log').children.length + ' lignes) :', [...$('log').children].slice(0, 4).map(x => x.textContent).join(' / '));
  $('seed').value = '7'; $('load').click(); await wait(300);
  console.log('rejouer le match 7 → horloge', $('clock').textContent, '| fil :', $('log').children.length, 'ligne(s)');
  fs.writeFileSync(__dirname + '/page.png', w.__canvas.toBuffer('image/png'));
  console.log('erreurs JavaScript :', errors.length ? errors : 'aucune');
  w.close(); process.exit(0);
})();
